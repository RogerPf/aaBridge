<?php

/**
 *     aacmn.php
 *
 *     merges the current   zz_common_header  into the source lin file
 */
error_reporting( E_ALL);
date_default_timezone_set( 'Europe/London');

main();

exit( 0);

// ****************************************************************************
function main() {
	global $pageCount;

	

	global $g;
	
	$g = new stdClass();
	
	$g->version = '2.60';  // 2017 Mar 12
	
	$extras = true;
		
// 	$g->input_override_filename  = "C:\\a\\test_in"; // omit the .lin
// 	$g->output_override_filename = "C:\\a\\test_output" ; // omit the .lin	

	/**
	 * Change lines into comments to give the standard operation
	 */
	
	global $pageCount;
	
	global $argv;
	
	if (isset( $g->input_override_filename)) {
		$fn_in = $g->input_override_filename . '.lin';
	}
	elseif (isset( $argv['1'])) {
		$fn_in = $argv['1'];
	}
	else {
		print "usage    scriptname.php <filename>" . PHP_EOL;
		exit( 2);
	}
	//$first3 = substr(, 0 ,3);
	
	$fcheck = fopen( $fn_in, "r");
	if ($fcheck === false) {
		print "cannot open file   $fn_in" . PHP_EOL;
		exit( 2);
	}
	
	$fn_in = stream_get_meta_data( $fcheck)["uri"];
	fclose( $fcheck);
	
	if (isset( $g->output_override_filename)) {
		$fn_out = $g->output_override_filename . '__hpg.lin';
	}
	else {
		//$fn_out = pathinfo( $fn_in)['dirname'] . '/' . pathinfo( $fn_in)['filename'] . '__hpg.lin';
		$fn_out = $fn_in;
	}
	
	$data = file_get_contents( $fn_in); // read in source html file (any UTF8 text file)


	$HEADER_FILE          = '<<--HEADER_FILE-->>';  // 	
	
	$g->common_header = rpf_findValue( $data, $HEADER_FILE, $rnt_not_used);
	
	if ($g->common_header == null)  {
	    $g->common_header = 'zz_common_header';  // .txt added later so we can test it as .lin first
	}
	
	if (strtolower($g->common_header) == "skip_this_file") {
		exit( 0);
	}
	
	$hf_len = strlen($g->common_header);
	$last_4 = strtolower(substr($g->common_header, $hf_len-4, 4));
	if ($last_4 === ".lin" || $last_4 === ".txt") {
	    $g->common_header = substr($g->common_header,0,$hf_len-4);
	}
	
	$fn_header = dirname( $fn_in) . '/' . $g->common_header . '.txt';
	
	$hc = '';
	if (file_exists( $fn_header)) {
		$hc = file_get_contents( $fn_header); // read in source html file (any UTF8 text file)
	}
	
	if ($hc == false) {
		$fn_header = dirname( $fn_in) . '/' . $g->common_header . '.lin';
	
		$hc = file_get_contents( $fn_header); // read in source html file (any UTF8 text file)
		if ($hc == false) {
			print "cannot open header file   $fn_header" . PHP_EOL;
			exit( 2);
		}
	}
	
	$HEADER_REPLACE_START = '<<--HEADER_REPLACE_START->>';
	$HEADER_REPLACE_END   = '<<--HEADER_REPLACE_END->>';
		
	$FPF_START            = '<<--FRONTPAGE_FOOTER_REPLACE_START->>';
	$FPF_END              = '<<--FRONTPAGE_FOOTER_REPLACE_END->>';
		
//	$len_HRS = strlen( $HEADER_REPLACE_START);

	$hc_HRS = get_pos_of_eol_after($data,  $HEADER_REPLACE_START);
	$hc_HRE = get_pos_of_eol_before($data,  $HEADER_REPLACE_END);
	
//	$hc_HRS = strpos( $data, $HEADER_REPLACE_START);
	if ($hc_HRS < 2) {
		print " No  $HEADER_REPLACE_START  found in    " . $fn_in . PHP_EOL;
		exit( 2);
	}
	
//	$len_HRE = strlen( $HEADER_REPLACE_END);
	
//	$to_HRE = strpos( $data, $HEADER_REPLACE_END);
	if ($hc_HRE < 2) {
		print " No  $HEADER_REPLACE_END   found in    " . $fn_in . PHP_EOL;
		exit( 2);
	}
	
	// $from_HRS += $len_HRS;
	
	/* We now extract the info-values from the two files
	 */
	$TOP_HEAD       = '<--TOP_HEAD-->';  // also funcitions as COMMON_HEADER_START
	$SECT_HEAD      = '<--SECT_HEAD-->';
	$CMN_HEADER_END = '<--COMMON_HEADER_END->'; 
	$CMN_FOOT_START = '<--FOOTER_CMN_START->';
	$CMN_FOOT_END   = '<--FOOTER_CMN_END->';
	
	$top_head    = rpf_findValue( $hc, $TOP_HEAD, $start_cmn);
	$select_head = rpf_findValue( $data, $SECT_HEAD, $rnt_not_used);
	
	
	$foot_from    = 	get_pos_of_eol_after($hc,  $CMN_FOOT_START);
	$foot_to      =     get_pos_of_eol_before($hc, $CMN_FOOT_END);

	if ($foot_from < 2) {
		print " No  $CMN_FOOT_START  found in   " . $fn_header . PHP_EOL;
		exit( 2);
	}
	
	if ($foot_from < 2) {
		print " No  $CMN_FOOT_END    found in   " . $fn_header . PHP_EOL;
		exit( 2);
	}
	
	if ($foot_from >= $foot_to) {
		print "Common header / footer in wrong order    " . $fn_header . PHP_EOL;
		exit( 2);
	}
	
	$new_foot     =     substr($hc, $foot_from, $foot_to - $foot_from);
	
	
	
	
	
// 	print  PHP_EOL. PHP_EOL. ">>>" . $new_foot . "<<<" .PHP_EOL;	
// 	for ($i = 0; ($i < strlen($new_foot)); $i++) {
// 		print ord($new_foot[$i]) . "." . $new_foot[$i] . "  ";
// 	}
	
	
	/* In a moment we will want to copy the later part of the common header to the output
	 * So we now adjust its contents NOW 
	 * IMPORTANT -  BEFORE THE SUBSTITUTIONS
	 */
	
	$hc_mod = substr( $hc, $start_cmn); // the common header minus the small unwanted intro
	
	/* NOW we can  insert the two values into the internal copy of the header
	 */
	$hc_mod = str_ireplace( $TOP_HEAD, $top_head, $hc_mod);
	$hc_mod = str_ireplace( $SECT_HEAD, $select_head, $hc_mod);
	
	$end_cmn = get_pos_of_eol_before($hc_mod, $CMN_HEADER_END);
	$hc_mod = substr( $hc_mod, 0, $end_cmn); //  remove the unwanted tail area in common
	
	
	$h_done = substr( $data, 0, $hc_HRS); // insert the first part of the data file
	
	$h_done .= $hc_mod;  // add modifed common header
	
	$h_done .= substr($data, $hc_HRE);  // add
	

	// here we replace the   FIRST_PAGE_FOOTER
	
	$fpf_from    = 	get_pos_of_eol_after($h_done,  $FPF_START);
	$fpf_to      =  get_pos_of_eol_before($h_done, $FPF_END);
	
	if ($fpf_from < 2) {
		print " No  $FPF_START  found in   " . $fn_in . PHP_EOL;
		exit( 2);
	}
	
	if ($fpf_to < 2) {
		print " No  $FPF_END    found in   " . $fn_in . PHP_EOL;
		exit( 2);
	}
	
	if ($foot_from >= $foot_to) {
		print "Common header / footer in wrong order    " . $fn_in . PHP_EOL;
		exit( 2);
	}
	
	$out = substr($h_done, 0 , $fpf_from);
	
	$out .= $new_foot;
	
	$out .= substr($h_done, $fpf_to);

	
	if ($extras) {
		$out = str_ireplace( '!S', '@s', $out);
		$out = str_ireplace( '!H', '@h', $out);
		$out = str_ireplace( '!D', '@d', $out);
		$out = str_ireplace( '!C', '@c', $out);
	}	
	
	// $out = $h_done;
	
	$fo = fopen( $fn_out, 'w'); // create the outputfile
	fwrite( $fo, $out);
	fclose( $fo);
	
	print "Done  $fn_in      $fn_out" . PHP_EOL;
	
	exit( 0);
}


//==================================================
function rpf_findValue( $data, $marker, & $rtn_to) {
	$marker .= '=';
	
	$lenMarker = strlen( $marker);
	
	$from = strpos( $data, $marker);
	
	if ($from <= 0)
		return '';
	
	$from += $lenMarker;
	
	$to = strpos( $data, "\n", $from);
	
	if ($to <= 0)
		return '';
	
	$rtn_to = $to + strlen("\n"); // to skip the next line character

	return substr( $data, $from, $to - $from);
}


//==================================================
function get_pos_of_eol_after( $data, $marker) {

	$from = strpos( $data, $marker);

	if ($from <= 0) {
		return -1;
	}

	$from2 = strpos( $data, "\n", $from);

	return $from2 + 1;
}


//==================================================
function get_pos_of_eol_before( $data, $marker) {

	$at = strpos( $data, $marker);

	if ($at <= 0) {
		return -1;
	}
	
	$at2 = strrpos( $data, "\n", $at - strlen($data));

	return $at2;
}







