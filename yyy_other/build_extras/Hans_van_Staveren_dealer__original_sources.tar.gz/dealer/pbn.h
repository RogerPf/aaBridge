#ifndef PBN_H
#define PBN_H
int printpbn (int, deal);

#endif /* PBN_H */
