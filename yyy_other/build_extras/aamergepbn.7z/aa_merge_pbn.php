<?php
error_reporting( E_ALL);

date_default_timezone_set( 'Europe/London');

main();

exit( 0);


// ****************************************************************************
function main() {
	
	$app_text  = "     Version 0.3    last updated  2016-08-31";
	
	
	global $argv;
	
	// print_r ($argv);
	
	$current_app_name = pathinfo( $argv[0], PATHINFO_BASENAME);
	$current_app_name = substr($current_app_name, 0, -4);
	
	
	$CR = chr( 13);
	$LF = chr( 10);
	
	$fn_out = "";
	$fn_out_short = "";
	
	
	$i = -1;
	
	$contents = array();
	$pbnFilesNames = array();
	$contNext = array();
	
	$newBoardNumber = 1;
	
	$out = "";
	
	$first = true;
	
	$number_per_parse = 1;
	
	foreach ($argv as $argKey => $fname) {
	
		if ($argKey == 0)
			continue;
	
		if ($argKey == 1 && ($argKey === "h" || $argKey === "-h")) {
			continue;
		}
		
		if ($argKey == 1 && strlen($fname) == 1) {
			if ($fname > 1 && $fname < 10)
				$number_per_parse = $fname;
			continue;
		}
		
		if (endsWith($fname, ".pbn") == false) {
			print "  File   $fname   does not end with    .pbn " . PHP_EOL;
			exit( 2);
		}
		
		if (in_array($fname, $pbnFilesNames)) {
			// this fixes argv duplication bug in DOS box windows 7 php ver 
			continue; 
		}
		
		$pbnFilesNames[] = $fname;	
	
		$file = fopen( $fname, "rb");
	
		if ($file === false) {
			print "  Cannot open file   $fname" . PHP_EOL;
			exit( 2);
		}
	
		print "  input file    " . pathinfo( $fname, PATHINFO_BASENAME) . PHP_EOL;
	
		$fs_in = stream_get_meta_data( $file)["uri"];
	
		$data = file_get_contents( $fs_in); // read in source lin file (any UTF8 text file)
	
		$data = str_ireplace( $LF . $CR, $LF, $data, $v0);
		$data = str_ireplace( $CR . $LF, $LF, $data, $v1);
		$data = str_ireplace( $CR,       $LF, $data, $v2);
	
		$raw_hands = explode($LF . $LF, $data);
		
		while (substr(end($raw_hands), 0, 1) != "[" ) {
			array_pop($raw_hands);
		}
		
		$cont = array();
		
		foreach ($raw_hands as $raw_h) {
			$cont[] = explode($LF, $raw_h);
		}
		
		$contents[] = $cont;
		
		$contNext[] = 0;
		
		if ($fn_out == "") {
			$remove_last_char = (strlen($fname) > 5) ? 1 : 0;
			$fn_out = substr($fname, 0, strlen($fname) - 4 - $remove_last_char) . "___MERGED___.pbn";
			$fn_out_short = pathinfo( $fn_out, PATHINFO_BASENAME);
		}
	}
	
	if ($fn_out == "") {
		print PHP_EOL . $current_app_name . $app_text . PHP_EOL . PHP_EOL;
		print "Usage:   "  .  PHP_EOL .  PHP_EOL;
		print "  $current_app_name   <OPTIONAL_single_digit>   <file_list>".  PHP_EOL .  PHP_EOL;
		print "    <OPTIONAL_single_digit>   =  the number of deals to be read from each .pbn file" . PHP_EOL;
		print "                                                      before moving to the next" . PHP_EOL;
		print "    <file_list>               =  a list of  .pbn  files" . PHP_EOL . PHP_EOL . PHP_EOL;
		
		print "  Example: " . PHP_EOL . PHP_EOL;
		print "     $current_app_name     file_one.pbn  file_two.pbn  file_three.pbn" . PHP_EOL . PHP_EOL. PHP_EOL ;

		print "    The output file will have a name like    file_on__MERGED__.pbn" . PHP_EOL . PHP_EOL;
		
		print "     (remember when typing filenames you can use  TAB for file name completion)" . PHP_EOL . PHP_EOL;
		
		exit(0);
	}
	
	if (count($contents) == 1) {
		print "  Only ONE input file supplied you TWO need to merge ". PHP_EOL . PHP_EOL;
		exit(2);
	}
	
	
	
	print "  output file   $fn_out_short" . PHP_EOL;
	
	$fo = fopen( $fn_out, 'w'); // create the outputfile // which will overwrite any existing file.
	
	
	/***
	 *  all the pbns have now been read in 
	 */
	
	$found = true;
	
	while ($found == true) {
		$found = false;

		foreach ($contents as $key => $cont) {
			for ($i = 0; $i < (int)$number_per_parse; $i++) { 
			
				if ($contNext[$key] < count($cont)) {

					write_hand_to_pbn_file( $fo, $first, $newBoardNumber, $contNext[$key], $cont[$contNext[$key]], $fn_out_short); 
					
					$found = true;								
					$first = false;
					$newBoardNumber++;
					$contNext[$key]++;
				}
			}
		}
	}
	
}


function endsWith($str, $end) {
	return substr( strToLower($str), - strlen( $end) ) === $end;
}


function write_hand_to_pbn_file( $fo, $first, $newBoardNumber, $key, $hand, $fn_out_short) {
	
	foreach ($hand as $line) {
		
		if ($first && substr($line, 0, 6) == '[Event') {
			
			static $start_match = 'with file ';
			$sm_len = strlen($start_match);
			$matchFrom = strpos($line, $start_match) + $sm_len;
			$final_dottxt = strrpos($line, '.txt' ) + 4;
			
			$script_name = "No_valid_dealer_script_filename_found_in_first_line_of_pbn_file.txt";
			$seed = "0000000000";
				
			if (($matchFrom > $sm_len)  &&  ($final_dottxt > $matchFrom)) {
				$script_name = substr($line, $matchFrom, $final_dottxt - $matchFrom);
				$script_name = trim($script_name);
				
				static $start_match2 = 'seed';
				$sm2_len = strlen($start_match2);
			    $matchFrom2 = strpos($line, $start_match2) + $sm2_len;
			    
			    $end2 = strrpos($line, '"' );
			    if (($matchFrom2 > $sm2_len) && ($end2 > 0)) {
			    	$seed = substr($line, $matchFrom2, $end2 - $matchFrom2);
			    	$seed = trim($seed);
			    }		    
			}

			$line = '[Event "Hand simulated by dealer with file __MERGED__inc__' . $script_name . ', seed ' . $seed . '"]';			
		}
		
		if (substr($line, 0, 6) === '[Board') {
			$line = '[Board "' . $newBoardNumber . '"]';
		} 
	
		fwrite( $fo, $line . chr(10));
		
		$z = "";	
	}
	
	fwrite( $fo, chr(10));
	flush( $fo);
}

