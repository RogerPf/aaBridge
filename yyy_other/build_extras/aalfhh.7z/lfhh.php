<?php
error_reporting( E_ALL);

date_default_timezone_set( 'Europe/London');

$inc_from = __DIR__ . DIRECTORY_SEPARATOR . 'all_inc' . DIRECTORY_SEPARATOR;

include ($inc_from . 'extract_codesfix.inc');
include ($inc_from . 'fonts_and_colors.inc');
include ($inc_from . 'import_export.inc');
include ($inc_from . 'tx_handler.inc');
include ($inc_from . 'main.inc');

main();

exit( 0);

// ****************************************************************************
function readControlAndDebugValues() {
	global $g;
	
	$g = new stdClass();
	
	/**
	 * Change lines into comments to give the standard operation
	 */
	
	global $argv;
	
// 	$g->grey_for_greying = '919191'; // comment out to stop feautre
	$g->move_b_pos_questions_to_p = true;
	$g->remove_prior_written = true;
	$g->suppress_extra_post_q_cr = true;
	
	if (isset( $argv[1]) && ($argv[1] == 'debug')) {
		unset( $argv[1]);

// 		$g->skip_to_page = 8;
// 		$g->max_pages = 4;
		

		$g->insert_regen_top_right_page_numbers = true;
		
//		$g->input_override_filename = "mentoring1411c_json.txt";
//		$g->input_override_filename = "bheval.htm";
//		$g->input_override_filename = "ment1101a_json.txt";
// 		$g->input_override_filename = "lrplay01-06_json.txt";
//		$g->input_override_filename = "/a/015  Other_Doubles.html";
// 		$g->input_override_filename = "bergentimingdefense.htm";
// 		$g->input_override_filename = "watson_1_3-4.htm";
//		$g->input_override_filename = "secondhandplay.txt";
//		$g->input_override_filename = "ek-03modernbridgedefensechapter3.htm";
//		$g->input_override_filename = "fg-07thinkwithfred26aug07.htm";
		
		$g->report_filename = "C:\\a\\zzReport.txt"; // normally NEVER commemnted out
		

		$g->output_override_filename = "C:\\a\\zzOutput__regen.lin";
	}
	// comment out to stop inclusion
//	$g->aaBridge_requirements_txt = 'at|^-Copyright material    -    NOT FOR PUBLIC DISTRIBUTION   -   Archive version' . PHP_EOL . '^-|ht|a|^a' . PHP_EOL;
	

	$g->progId = "'aa_lin_from_html.php'    v_0.17      last changed on   2015 May 02"; // DO NOT COMMENT OUT
	
//	2015 May 02   0.17   recognises 2 column bidding panels (always did 4 column)  'im'  now ignored
}

