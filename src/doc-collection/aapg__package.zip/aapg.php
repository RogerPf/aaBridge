<?php

/**
 *     aapg.php
 *
 *     adds pg numbers in the unused data portion of |pg| commands
 *     
 *     this lets you easily find and goto the page you want to change.
 *     
 *     usage  (in a  'WIN cmd box'  or 'MAC terminal')
 *     
 *                aapg.php   <file-you-want-to-change.lin>
 *                
 *     For complete installation instruction (inc php) see the 
 *     aapg install and dev guide that comes with aaBridgge.           
 *     
 *     version 0.09
 *     
 *     Roger Pfister       2015 June 11
 */

//$input_override_filename  = "C:\\c\\cphp\\aa_pg\\pg_test_movie.lin";
//$input_override_filename  = "C:\\a\\mentoring2014\\mentoring1409a.lin";
//$output_override_folder   = "C:\\a\\pg_out_folder";
//$input_override_filename  = "C:\\c\\cphp\\Officer Precision\\payload\\XX009   5a  1NT Opening.lin";

//$output_suppressed = true;

{
	//
	// Programmers only  below HERE ----------------------------------------------
	//
	error_reporting( E_ALL);

//	$EOL_choice = 'Win';
	$EOL_choice = 'MAC';
	
	$current_app_name = pathinfo( $argv[0], PATHINFO_BASENAME);
	$current_app_name = substr($current_app_name, 0, -4);
	
	$arg1 = '';
	$arg2 = '';
	
	if (isset($argv['1'])) {
		$arg1 = $argv['1'];
	}
	
	if (isset($argv['2'])) {
		$arg2 = $argv['2'];
	}
	
	// print "---  $arg1   $arg2  ===\n";
	
	if (strtolower($arg1) == '-w') {
		$EOL_choice = 'Win';
		$arg1 = $arg2;
	}

	if (strtolower($arg1) == '-m') {
		$EOL_choice = 'MAC';
		$arg1 = $arg2;
	}

	$pageCount = 0; // the first page of a lin file is numbered 0 (zero) and not displayed
	$lc_in = 1; // lines are numbered from 1 because that is what most editors do.
	
	$CR = chr( 13);
	$LF = chr( 10);
	
	if (isset( $EOL_choice) == false) {
		// here MAC includes UNIX and all others
		$EOL_choice = (substr( PHP_OS, 0, 3) === 'WIN') ? 'Win' : 'MAC';
	}
	
	if ($EOL_choice == 'MAC') {
		$eol = $LF;
		$discard_CR = true;
	}
	else {
		$eol = $CR . "" . $LF;
		$discard_CR = false;
	}
	
	if (isset( $input_override_filename)) {
		$fn = $input_override_filename;
	}
	elseif (isset( $arg1)) {
		$fn = $arg1;
	}
	
	if (!isset( $fn) || $fn == '' || $fn == null) {
		print 'usage        ' . $current_app_name . '     YOUR_FILE.lin' . PHP_EOL;
		exit( 2);
	}
	
	if (strcasecmp( substr( $fn, -4), '.lin') == 0) { // 0 means matches	
		$fn_no_ext = substr( $fn, 0, strlen( $fn) - 4);
	}
	else {
		$fn_no_ext = $fn;
	}
	
	$fn_in = $fn_no_ext . '.lin'; // so the extension is always lowercase
	

	//
	// the 'long way' to open a file but it *really* makes sure that it exists before we do open it
	//
	$fcheck = @fopen( $fn_in, "r");
	if ($fcheck === false) {
		print ("cannot open file   $fn_in" . PHP_EOL);
		exit( 2);
	}
	$fn_in = stream_get_meta_data( $fcheck)["uri"];
	fclose( $fcheck);
	//
	//
	//
	

	if (isset( $output_override_folder)) {
		$fn_out = $output_override_folder . DIRECTORY_SEPARATOR . pathinfo( $fn_in, PATHINFO_FILENAME);
		if (!file_exists( $output_override_folder)) {
			mkdir( $output_override_folder);
		}
	}
	elseif (isset( $output_override_filename)) {
		if (strcasecmp( substr( $output_override_filename, -4), '.lin') == 0) { // 0 means matches	
			$fn_out = substr( $output_override_filename, 0, strlen( $output_override_filename) - 4);
		}
		else {
			$fn_out = $output_override_filename;
		}
	}
	else {
		$fn_out = $fn_no_ext;
	}
	
	if (@$append__pg_numbered) {
		if (substr( $fn_out, -13) != '__pg-numbered') {
			$fn_out .= '__pg-numbered';
		}
	}
	
	$fn_out = $fn_out . '.lin'; // so the extension is always lowercase
	

	// Read in ALL the .lin file
	$data_orig = file_get_contents( $fn_in); // read in source lin file (any UTF8 text file)	
	$data = $data_orig . '  '; // extra spaces to make the parsing easier;

	$state = 'cmd'; // we start in command hutting mode
	

	$out = '';
	
	$in_pg_data = false;
	$pg_count = 0;
	
	$data_len = strlen( $data);
	
	$x = ''; // trying to detect when the lin file is out of alignment
	$a = '';
	$b = $data[0];
	$c = $data[1];
	
	if ($b == $LF) {
		$lc_in++;
	}
	
	if ($c == $LF) {
		$lc_in++;
	}
	
	$output_produced_ok = true;
	$alignment_issues = 0;
	
	/* 
	 * The MAIN loop checking each character =====================================
	 */
	for ($i = 2; $i < $data_len; $i++) {
		
		$x = $a;
		$a = $b;
		$b = $c;
		$c = $data[$i];
		
		if ($c == $LF)
			$lc_in++;
		
		if ($in_pg_data) {
			if ($c == '|') {
				// skip all cr lf   that are ahead of us
				while ( true ) {
					if ($data[$i + 1] == $CR || $data[$i + 1] == $LF) {
						if ($data[$i + 1] == $LF) {
							$lc_in++;
						}
						$i++;
						continue;
					}
					break;
				}
				$out .= '|' . $eol . $eol . $eol;
				$a = '';
				$b = '';
				$c = '';
				$in_pg_data = false;
				
				$state = 'cmd';
			}
			continue; // so discarding the current c$	
		}
		
		if (($state == 'cmd') && ($c == '|')) {
			
			if ((!empty( $x)) && ($x != '|') && ($x != $LF)) {
				$p = 0;
				for (; $p < 40; $p++) {
					if ($data[$i - ($p + 1)] == $LF)
						break;
				}
				$seg = substr( $data, $i - $p, $p + 1);
				
				$ln = substr( "Line " . $lc_in . "       ", 0, 11);
				print ("$ln $fn_in      alignment    $seg " . PHP_EOL);
				
				$output_produced_ok = false; // we are only hunting for errors from now on  - no output
				

				$alignment_issues++;
				if ($alignment_issues >= 5) {
					break; // end and quit
				}
				
				$in_pg_data = false;
				continue; // as we suspect we are wrongly in 'cmd' mode we stay in 'cmd' as it should now be correct
			}
			
			if (($a == 'p' || $a == 'P') && ($b == 'g' || $b == 'G')) { // pg
				

				$in_pg_data = true;
				while ( true ) { // strip existing  CR's and LF's  so multi pg's comeout togeater
					$ol = strlen( $out) - 1;
					if ($out[$ol] == $CR || $out[$ol] == $LF) {
						$out = substr( $out, 0, $ol);
						continue;
					}
					break;
				}
				$out .= $eol . $a . $b . '| ***** ' . $pg_count++ . ' ***** ';
				$a = '';
				$b = '';
				$c = ''; // to suppress the bar output
			}
			else if (($a == 'l' || $a == 'L') && ($b == 'b' || $b == 'B')) {
				$pg_count++;
			}
			
			$state = 'data';
		}
		
		else if ($state == 'data' && ($c == '|')) {
			$state = 'cmd';
			$in_pg_data = false;
		}
		
		if ($in_pg_data) {
			continue; // pg data is ALWAYS discarded and replaced with a newly generated pg number
		}
		
		if ($discard_CR) { // we are mac / unix
			if ($a == $CR) {
				$a = '';
			}
		}
		else { // we want windows output
			if ($a == $LF && $x != $CR) {
				$out .= $CR;
			}
		}
		$out .= $a;
	}
	
	if ($output_produced_ok) {
				
		if (@$output_suppressed == true) {
			print ("In         $fn_in             Out   none  output_suppressed -set- true" . PHP_EOL);
		}
		else {
			$fo = fopen( $fn_out, 'w'); // create the outputfile // which will overwrite any existing file.
			fwrite( $fo, $out);
			fclose( $fo);
			print ("In         $fn_in             Out   $fn_out" . PHP_EOL);
		}
	}
	
	exit( 0);
}


