
With this read me are three pdf files with kind permission of Howard Schutzman Hondo717

			http://www.bridgesights.com/hondobridge/
			
They are the comprehensive text that goes with the three lin file that you can 
find INSIDE aaBridge 

	Menubar   >    Books_S   >   Lessons - Weak NT 12-14  with 5 card majors
	
--
