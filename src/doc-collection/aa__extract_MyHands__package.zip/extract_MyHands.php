<?php
/**
 *   aa_big_lin_from_html
 *
 *   extracts all the lin files from a bbo MyHands web page
 *
 *   Roger Pfister  -  2017 March
 */
aa_main_loop(); // do it
exit(0);

// ****************************************************************************
function aa_main_loop()
{
    /**
     * You can change these values
     *
     * As this is PHP you use ***forward*** slashes in the path
     * below, !!! EVEN on Windows !!!
     *
     * -
     */
    $rotate_you_to_south = true;

    $always_delete_lin_files = true;

    $add_treat_as_virgin_cmd = true;

    $output_folder__override = ''; // Recommended to leave it EMPTY and so use, temp_MyHands

    $source_folder__override = ''; // Recommended to leave it EMPTY and so use the Standard Downloads folder

    $html_source_file = "Bridge Base Online - Myhands";

    /**
     * -
     *
     * End of changeable values
     */

    global $argv;
    print basename($argv[0]) . '   v 1577     2017-07-05           running on  PHP ' . phpversion() . PHP_EOL;

    if (phpversion() < 7.0) {
        date_default_timezone_set('UTC');
    }

    error_reporting(E_ALL);

    if (@startsWith($_SERVER['OS'], 'Win')) {
        $home_folder = $_SERVER['HOMEDRIVE'] . $_SERVER['HOMEPATH'];
    } else {
        $home_folder = $_SERVER['HOME'];
    }

    if (empty($output_folder__override) === false) {
        $output_folder = $output_folder__override;
    } else {
        $output_folder = $home_folder . DIRECTORY_SEPARATOR . 'aaBridge' . DIRECTORY_SEPARATOR . 'temp_MyHands';
    }

    if (empty($source_folder__override) === false) {
        $source_folder = $source_folder__override;
    } else {
        $source_folder = $home_folder . DIRECTORY_SEPARATOR . 'Downloads';
    }

    global $g;
    $g = new StdClass();

    $filename = $source_folder . '/' . $html_source_file;

    if (endsWith($filename, '.html') == false) {
        $filename .= '.html';
    }

    if (file_exists($filename) == false) {
        print("  Input file   $filename   does not exist  please check the settings at " . PHP_EOL . '     the start of    ' . $argv[0] . PHP_EOL);
        exit(2);
    }

    $contents = file_get_contents($filename);

    $contents = mb_convert_encoding($contents, 'HTML-ENTITIES', 'UTF-8');

    // $contents = str_replace('<tr class="highlight">', '<tr class="mbc">', $contents);
    // $contents = str_replace('<tr class="tourney">', '<tr class="mbc">', $contents);

    $from = 0;
    $raw = extract_simple($contents, $from, 'played by <span class=', '/span');
    $from = 0;
    $g->bboid = extract_simple($raw, $from, '>', '<');
    $from = 0;

    $date_recog = '<th colspan="11">20';

    $ymdAy = array();

    /**
     * find the dates that are in std myHands for each day
     */
    while (true) {
        $date_start = mb_strpos($contents, $date_recog, $from, 'UTF-8');
        if ($date_start === false)
            break;
        $from = $date_start;
        $date_start += strlen($date_recog) - 2;
        $date_end = mb_strpos($contents, '</th>', $from, 'UTF-8');
        if ($date_end === false)
            break;
        $ymd = mb_substr($contents, $date_start, $date_end - $date_start, 'UTF-8');

        $from = $date_start;

        $ymdAy[] = new YMD($ymd, $from);
    }

    $isFromTrav = (count($ymdAy) == 0);

    $from = 0;

    $dealAy = array();

    /**
     * Read in all the deals
     */
    while (true) {

        $tr_start = mb_strpos($contents, '<td class="handnum">', $from, 'UTF-8');
        if ($tr_start === false)
            break;

        $highlighted = (strpos($s = mb_substr($contents, $tr_start - 50, 50, 'UTF-8'), 'highlight') !== false);

        $tr_end = mb_strpos($contents, '</tr>', $tr_start);
        if ($tr_end === false)
            break;

        $ymd = YMD::getYmd($ymdAy, $tr_start);

        $d = mb_substr($contents, $tr_start, $tr_end - $tr_start, 'UTF-8');

        $dealAy[] = new Deal($d, $ymd, $highlighted);

        $from = $tr_end + 5;
    }

    if (count($dealAy) == 0) {
        print('    No deals found in       ' . $filename . PHP_EOL);
        exit(0);
    }

    if ($always_delete_lin_files) {
        delete_existing_lins($output_folder);
    }

    if (file_exists($output_folder) == false) {
        mkdir($output_folder);
    }

    foreach ($dealAy as $deal) {
        $deal->saveAsLin($output_folder, $isFromTrav, $rotate_you_to_south, $add_treat_as_virgin_cmd);
    }

    print '    ' . count($dealAy) . '  lin files written' . PHP_EOL;

    $z = 0;
}

// ****************************************************************************
function delete_existing_lins($out_folder)
{
    foreach (glob("$out_folder/*.lin") as $filename) {
        @unlink($filename);
    }
}

// ****************************************************************************
// ****************************************************************************
class YMD
{

    public $ymd;

    public $line;

    public function __construct($ymd, $line)
    {
        $this->ymd = $ymd;
        $this->line = $line;
    }

    static function getYmd($ay, $position)
    {
        if (empty($ay)) {
            return "";
        }
        $prev_ymd = "";
        $prev_line = 0;
        foreach ($ay as $entry) {
            if ($entry->line > $position)
                break;
            $prev_ymd = $entry->ymd;
            $prev_line = $entry->line;
        }
        return $prev_ymd;
    }
}

// ****************************************************************************
function extract_td_val($ds, &$start, $param, $advance)
{
    $td_param = '<td class="' . $param . '">';
    $td_end = '</td>';

    $p_start = mb_strpos($ds, $td_param, $start, 'UTF-8');
    if ($p_start === false)
        return '';
    $p_start += mb_strlen($td_param, 'UTF-8');

    $p_end = mb_strpos($ds, '</td>', $p_start, 'UTF-8');

    if ($p_end === false)
        return '';

    if ($advance) {
        $start = $p_end + mb_strlen($td_end, 'UTF-8');
    }

    return mb_substr($ds, $p_start, $p_end - $p_start, 'UTF-8');
}

// ****************************************************************************
function extract_time($ds, &$start, $ymd)
{
    $td_param = '<td>';
    $td_end = '</td>';

    $p_start = mb_strpos($ds, $td_param, $start, 'UTF-8');
    if ($p_start === false)
        return '';
    $p_start += mb_strlen($td_param, 'UTF-8');

    $p_end = mb_strpos($ds, '</td>', $p_start, 'UTF-8');

    if ($p_end === false)
        return '';

    $start = $p_end + mb_strlen($td_end, 'UTF-8');

    $t = mb_substr($ds, $p_start, $p_end - $p_start, 'UTF-8');

    if (strlen($t) == 5) {
        $t = $ymd . ' ' . $t;
    }

    return DateTime::createFromFormat('Y-m-d H:i', $t);
}

// ****************************************************************************
function extract_simple($ds, &$start, $param, $param_end)
{
    $ds = str_replace('&#39;', "'", $ds);

    $u_param = mb_strtoupper($param, 'UTF-8');
    $u_ds = mb_strtoupper($ds, 'UTF-8');

    $p_start = mb_strpos($u_ds, $u_param, $start, 'UTF-8');
    if ($p_start === false)
        return '';
    $p_start += mb_strlen($param, 'UTF-8');

    $p_end = mb_strpos($ds, $param_end, $p_start, 'UTF-8');

    if ($p_end === false)
        return '';

    $start = $p_end + mb_strlen($param_end, 'UTF-8');

    return mb_substr($ds, $p_start, $p_end - $p_start, 'UTF-8');
}

// ****************************************************************************
function extract_lin_and_handlink($ds, &$start, &$lin, &$handlink, &$when, &$id, &$boardnum)
{
    $td_param = '<td class="movie">';
    $p_start = mb_strpos($ds, $td_param, $start, 'UTF-8');
    if ($p_start === false)
        return - 1;
    $p_start += mb_strlen($td_param, 'UTF-8');

    $handlink = extract_simple($ds, $p_start, '<a href="', '"');

    $handlink = str_replace('&amp;', '&', $handlink);

    $start = $p_start;

    $p_start = 0;

    $lin_orig = extract_simple($ds, $p_start, "hv_popuplin('", "');");

    $lin = urldecode($lin_orig);

    $v = explode('-', $handlink, 3);

    $when = $v[2];
    $id = $v[1];

    $findit = 'ah|Board ';
    $p_start = mb_strpos($lin, $findit, 0, 'UTF-8');
    if ($p_start === false)
        return;
    $p_start += strlen($findit);

    $p_end = strpos($lin, '|', $p_start);

    $boardnum = substr($lin, $p_start, $p_end - $p_start);
}

// ****************************************************************************
function extract_contract_and_result($ds, $start, &$score)
{
    $raw = extract_td_val($ds, $start, 'result', true /* advance */);

    // skip the next td points scored

    $td_param = '<td class=';
    $p_start = mb_strpos($ds, $td_param, $start, 'UTF-8');
    $p_start += strlen($td_param);

    $p_start = mb_strpos($ds, $td_param, $p_start, 'UTF-8');
    $p_start += strlen($td_param);

    $score = extract_simple($ds, $p_start, ">", "<");

    if ($raw === 'PASS') {
        return '-PASS-';
    }
    if ($raw === 'A==') {
        return '-AVE-';
    }

    if (strlen($raw) < 4) {
        return '-QQQQ-';
    }

    $level = substr($raw, 0, 1);
    if ($level < 1 || 7 < $level) {
        return 'level-' . $level;
    }

    $si = '';
    $rest = '';

    if (substr_count($raw, '<span') == 0) {
        $si = 'N'; // NT
        $rest = substr($raw, 2);
    } else if (mb_substr_count($raw, '♣', 'UTF-8') > 0) {
        $si = 'C';
    } elseif (mb_substr_count($raw, '♦', 'UTF-8') > 0) {
        $si = 'D';
    } elseif (mb_substr_count($raw, '♥', 'UTF-8') > 0) {
        $si = 'H';
    } elseif (mb_substr_count($raw, '♠', 'UTF-8') > 0) {
        $si = 'S';
        //
    } elseif (mb_substr_count($raw, '&clubs;', 'UTF-8') > 0) {
        $si = 'C';
    } elseif (mb_substr_count($raw, '&diams;', 'UTF-8') > 0) {
        $si = 'D';
    } elseif (mb_substr_count($raw, '&hearts;', 'UTF-8') > 0) {
        $si = 'H';
    } elseif (mb_substr_count($raw, '&spades;', 'UTF-8') > 0) {
        $si = 'S';
    } else {
        return '-';
    }

    $match = "</span>";
    $p_start = mb_strpos($raw, $match, 0, 'UTF-8');
    if ($p_start !== false) {
        $rest = mb_substr($raw, $p_start + strlen($match), null, 'UTF-8');
    }

    if (startsWith($rest, 'x')) {
        $si .= 'x';
        $rest = substr($rest, 1);
    }

    if (startsWith($rest, 'x')) {
        $si .= 'x';
        $rest = substr($rest, 1);
    }

    $s = $level . $si . ' ' . $rest;

    return $s;
}

/**
 * extract_traveller
 */
// ****************************************************************************
function extract_travellerlink($ds, $start, &$traveller)
{
    $trav_core = extract_td_val($ds, $start, 'traveller', true /* advance */);

    if (strlen($trav_core) == 0) {
        return;
    }

    $match = '<A HREF="';
    // $u_ts = mb_strtoupper($trav_core, 'UTF-8');
    // $p_start = mb_strpos($u_ts, $match, 0, 'UTF-8');
    // // if ($p_start === false)
    // // return;
    $p_start = 0;

    $trav = extract_simple($trav_core, $p_start, $match, '">');
    if (strlen($trav) == 0) {
        return;
    }

    $trav = str_replace('&amp;', '&', $trav);

    $site = 'http://www.bridgebase.com';

    if (strpos($trav, $site) === false) {
        $slash = startsWith($trav, '/') ? '' : '/';
        $trav = $site . $slash . $trav;
    }

    $traveller = $trav;
}

// ****************************************************************************
// ****************************************************************************
class Deal
{

    public $handnum = "";

    public $time = 0;

    public $boardnum = "";

    public $players = array();

    public $compass = array(
        's',
        'w',
        'n',
        'e'
    );

    public $youseat = 's';

    public $youseatind = 0;

    /* */
    public $contract = "";

    public $score = "";

    public $lin = "";

    public $handlink = "";

    public $brokenwhen = "";

    public $id = "";

    public $travellerlink = "";

    public $higlighted = false;

    // ****************************************************************************
    public function __construct($d, $ymd, $highlighted)
    {
        global $g;

        $this->highlighted = $highlighted;

        $this->handnum = extract_td_val($d, $start, 'handnum', true /* advance */);
        $this->time = extract_time($d, $start, $ymd);
        $this->players[] = unBot(extract_td_val($d, $start, 'south', false /* advance */));
        $this->players[] = unBot(extract_td_val($d, $start, 'west', false /* advance */));
        $this->players[] = unBot(extract_td_val($d, $start, 'north', false /* advance */));
        $this->players[] = unBot(extract_td_val($d, $start, 'east', false /* advance */));

        for ($i = 3; ($i > 0); $i --) {
            if (mb_strtolower($this->players[$i], 'UTF-8') === mb_strtolower($g->bboid, 'UTF-8')) {
                $this->youseatind = $i;
                $this->youseat = $this->compass[$i];
                break;
            }
        }

        $this->contract = extract_contract_and_result($d, $start, $this->score);

        extract_lin_and_handlink($d, $start, $this->lin, $this->handlink, $this->brokenwhen, $this->id, $this->boardnum);

        /* if the deal is from a traveller the travellerlink will be empty */
        extract_travellerlink($d, $start, $this->travellerlink);

        $z = 0;
    }

    // ****************************************************************************
    public function getLinWithAddedFormatting($qx_numb, $rotate_you_to_south)
    {
        $rot_cmd = $rotate_you_to_south ? ('rt|' . ((4 - $this->youseatind) % 4) . "|\n") : '';

        // strip off the st|| and players names - they go back later
        $p = mb_strpos($this->lin, '|md|', 0, 'UTF-8');
        $lin = mb_substr($this->lin, $p + 1, null, 'UTF-8');

        $s = "qx|$qx_numb|";

        $s .= 'pn|' . $this->players[0] . ',' . $this->players[1] . ',' . $this->players[2] . ',' . $this->players[3] . "|\n";

        $s .= $lin;

        $s = str_replace('|rh||', "|\n" . $rot_cmd . 'rh||', $s);

        $sv_start = strpos($s, '|sv|', 0);
        $sv_end = strpos($s, '|', $sv_start + 4);
        $sv = substr($s, $sv_start, $sv_end + 1 - $sv_start);
        $s = str_replace($sv, $sv . 'sk|' . $this->youseat . "|\n", $s);

        $mc = "";
        $mc_pos = strpos($s, '|mc|');
        if ($mc_pos !== false) {
            $mc = substr($s, $mc_pos + 1);
            $s = substr($s, 0, $mc_pos + 1);
        }

        $pg_at_end = false;
        $pc = "";
        $pc_pos = strpos($s, '|pc|');
        if ($pc_pos !== false) {
            $pc = substr($s, $pc_pos, strlen($s) - ($pc_pos + 1));
            $s = substr($s, 0, $pc_pos + 1);

            $cards = explode('|pc|', $pc);

            foreach ($cards as $i => $card) {
                $pg_at_end = false;
                if ($i == 0) {
                    ; // nothing
                } else if ($i == 1) {
                    $s .= "pg||\npc|$card|pg||";
                    $pg_at_end = true;
                } elseif ($i % 4 == 0) {
                    $s .= "pc|$card|pg||\n";
                    $pg_at_end = true;
                } else {
                    $s .= "pc|$card|";
                }
            }

            if ($pg_at_end == false) {
                $s .= "pg||\n";
            }

            if (strlen($mc) > 0) {
                $s .= $mc;
            }

            $z = 0;
        }

        if (endsWith($s, "pg||\n")) {
            $s = substr($s, 0, strlen($s) - 5);
        }

        $s .= "\n\nqx|end,wide|ht|z|at|^^^a^*bend^*n|pg||\n";

        return $s;
    }

    // ****************************************************************************
    public function saveAsLin($outfolder, $isFromTrav, $rotate_you_to_south, $add_treat_as_virgin_cmd)
    {
        $i = strlen($this->boardnum);

        $bn = substr('   ' . $this->boardnum, strlen($this->boardnum), 3);

        $fn_score = '-';
        if (strpos($this->score, '%') !== false) {
            if /*-*/ ($this->score > 60) {
                $fn_score = 'a';
            } elseif ($this->score > 55) {
                $fn_score = 'b';
            } elseif ($this->score > 45) {
                $fn_score = 'c';
            } elseif ($this->score > 40) {
                $fn_score = 'd';
            } else {
                $fn_score = 'e';
            }
        } else {
            if /*-*/ ($this->score > 4) {
                $fn_score = 'A';
            } elseif ($this->score > 1.5) {
                $fn_score = 'B';
            } elseif ($this->score > - 1.5) {
                $fn_score = 'C';
            } elseif ($this->score > - 4) {
                $fn_score = 'D';
            } else {
                $fn_score = 'E';
            }
        }

        if ($isFromTrav) {
            $hn = substr('00' . $this->handnum, strlen($this->handnum), 2);
            $fname = 't_' . $hn;
            $qx_numb = $this->boardnum;
            $hl = ($this->highlighted) ? '===' : '';
        } else {
            $hn = substr('00' . $this->handnum, strlen($this->handnum), 2);
            $fname = $this->time->getTimestamp() . $hn . ' ' . $hn . ' ' . $bn;
            $qx_numb = $this->handnum;
            $hl = '';
        }

        $fname .= '  ' . $fn_score . '  ' . $this->contract . '   ' . $hl;

        $fname = str_pad($fname, 40);

        $fname .= $this->time->format('D    Y-m-d  H.i') . '    ';

        foreach ($this->players as $player) {
            $fname .= str_pad($player, 12);
        }
        $fname .= '.lin';

        @$fout = fopen($outfolder . '/' . $fname, 'w');

        if ($fout === false) {
            print('Failed to open (in write mode) file - ' . $fname . PHP_EOL);
            return;
        }

        if ($add_treat_as_virgin_cmd) {
            fwrite($fout, 'vr||' . "\n");
        }

        fwrite($fout, 'nt|^b@2^^|' . "\n");

        $pos_red = '';

        $score = $this->score;

        if (strpos($this->score, '%') !== false) {
            $iorm = 'MP\'s';
            $score = ' ' . $score;
            if ($this->score < 50) {
                $pos_red = 'red';
            }
        } else {
            $iorm = 'IMP\'s';
            if ($this->score < 0.0)
                $pos_red = 'red';
            else
                $score = ' ' . $score;
        }

        $s = "at|Played on        ";
        $s .= $this->time->format('l     \^\h   Y-m-d     \a\t     H:i       \(g:i a\)');
        $s .= ' ^q   ' . $iorm . '^s |cp|' . $pos_red . '|at|^*b' . $score . '^*n|cp||at|';
        $s .= ' ^u \' ' . $fn_score . ' \'^^^^^^|';

        fwrite($fout, $s . "\n\n");

        if (strLen($this->handlink) > 0) {
            $s = 'at| ^*h ' . $this->handlink . ' , Show the deal^*n      ^g   using the BBO Hand Viewer^^^^|';
            fwrite($fout, $s . "\n\n");
        }

        if (strLen($this->travellerlink) > 0) {
            $s = 'at| ^*h ' . $this->travellerlink . ' , Show the traveller^*n   ^g   using the BBO MyHands website';
            $s .= '^^^^ |';
            fwrite($fout, $s . "\n\n");
        } else {
            $s = 'at| This hand was downloaded as a part of a traveller.^^^^|';
            fwrite($fout, $s . "\n\n");
        }

        fwrite($fout, $this->getLinWithAddedFormatting($qx_numb, $rotate_you_to_south) . "\n");
    }
}

// ****************************************************************************
// ****************************************************************************
function startsWith($haystack, $needle)
{
    $length = strlen($needle);
    return (substr($haystack, 0, $length) === $needle);
}

// ****************************************************************************
// ****************************************************************************
function endsWith($haystack, $needle)
{
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }
    return (substr($haystack, - $length) === $needle);
}

// ****************************************************************************
// ****************************************************************************
function unbot($player)
{
    return startsWith($player, '~~') ? ' bbo__bot' : $player;
}

