#!/bin/bash

cd "$(dirname "$0")"

chmod u+x  "./MAC__SETUP_action.command"

source ./MAC__SETUP_action.command


# do the extra bits for Linux 32

chmod u+x  "./MAC/dealer_linux_32bit"

RPf_to="$HOME/aaBridge/cmds_and_scripts/"
cp     "./MAC/dealer_linux_32bit"            "${RPf_to}dealer"


RPf_to="../../dealer_scripts/"
cp     "./MAC/dealer_linux_32bit"            "${RPf_to}dealer"

printf '\nLinux 32 Bit extras also  ...done...\n\n'
