<?php

/**
 *     aapg.php
 *
 *     does two things
 *
 *     1) Scans for insert file markers 'START' and 'END**'
 *     then replaces the text between the markers with the
 *     text from the file named in the markers.
 *
 *     2) Adds 'pg' numbers in the unused data portion of |pg| commands
 *     this lets you easily find and goto the page you want to change.
 *     usage  (in a  'WIN cmd box'  or 'Mac terminal')
 *
 *        aapg.php   <file-spec wild cards allowed>  default <*.lin>
 *
 *     only '.lin' files are processed whatever the file spec.
 *
 *     For complete installation instruction (inc php) see the
 *     aapg install and dev guide that comes with aaBridgge.
 *
 *     Roger Pfister
 */
main();

exit(0);

// ****************************************************************************
function main ()
{
   global $g;
   $g = new stdClass();
   $g->version = 3.36; // 2018 Oct 01

//   $g->EOL_choice = 'LF';

   if (isset($g->EOL_choice) == false) {
      $g->EOL_choice = (substr(PHP_OS, 0, 3) === 'WIN') ? 'CRLF' : 'LF';
   }

   if (file_exists("C:\\ProgramSmall\\aaBridge\\aaBridge__aaa_use_LF.txt")) {
      $g->EOL_choice = "LF";
   }

   /*
    * FOR TESTING ONLY
    *
    * Change lines into comments to give the standard operation
    */

   // $g->input_override_filename = 'C:\c\cphp\aa_pg\local_tests_INPUT\*.*';
   // $g->input_override_filename = 'C:\c\cphp\aa_pg\RELEASE_files\*.*';
   // $g->input_override_filename = 'C:\d\BM__All\aains_EXAMPLE\*.*';
   // $g->input_override_filename = '?';
   // $g->input_override_filename = '*.lin';

   // $g->output_override_folder = 'C:\c\cphp\aa_pg\local_tests_OUTPUT';
   // $g->output_override_folder = 'C:\a\aapg_redirected_OUTPUT';
/*
 * end TESTING Change lines
 */

   $g->show_in_filename_short = true;

   error_reporting(E_ALL);

   if (phpversion() < 7.0) {
      date_default_timezone_set('UTC');
   }

   error_reporting(E_ALL);

   define('INSERT_START', '<<--INSERT-START-->>=');
   define('INSERT_END', '<<--INSERT-END**-->>=');
   define('BEFORE_EXC', '<--THIS-LINE-AND-ALL-BEFORE-EXCLUDED-->');
   define('AFTER_EXC', '<--THIS-LINE-AND-ALL-AFTER-EXCLUDED-->');
   define('NEAR_STR', '%%_aapg-NEAR');
   define('STD_STR', '%%_aapg-STD');
   define('PLING2AT', '%%_aapg-PLING2AT');

   global $argv;
   $usage = ' usage     ' . substr(pathinfo($argv[0], PATHINFO_BASENAME), 0, - 4) . '  <linfile list>   inc wild cards,  defaults to  *.lin' . PHP_EOL;

   $filelist = array();

   /*
    * discard all other filenames
    */
   if (isset($g->input_override_filename)) {
      $ag0 = $argv['0'];
      $argv = array(); // clear the array
      $argv['0'] = $ag0;
      $argv['1'] = $g->input_override_filename; // it also may be -? or ? or
      // /?
   }

   if (isset($argv['1']) == false) {
      $argv['1'] = '*.lin';
   }

   if ((strlen($argv['1']) < 3) && ($argv['1'] != "*")) {
      print " " . $usage . PHP_EOL;
      exit(2);
   }

   /*
    * for each supplied argument "glob" it
    * and for each valid lin file
    * call the ins merge and pg functions
    */
   for ($u = 1; isset($argv[$u]); $u ++) {
      $v = $argv[$u];

//       if ((strpos($v, '\\') !== false) || (strpos($v, '/') !== false) || (strpos($v, ':') !== false)) {
//          $filelist[] = $v;
//       }
//       else ...

      // this make ".lin" case insensitive needed even for windows
      if ((strlen($v) > 4) && substr(strtolower($v), - 4) == '.lin') {
         $v = substr($v, 0, - 4) . '.[lL][iI][nN]';
      }

      foreach (glob($v) as $fn) {
         if ((strlen($fn) < 5) || (substr(strtolower($fn), - 4) != '.lin')) {
            continue;
         }
         $filelist[] = $fn;
      }
   }

   if (count($filelist) == 0) {
      print "aapg.php v$g->version   No matching files found         (PHP ver " . phpversion() . ')' . PHP_EOL;
      print "  " . $usage . PHP_EOL;
      exit(2);
   }

   print "aapg.php v$g->version" . PHP_EOL;
   // print '  --' . PHP_EOL;

   foreach ($filelist as $fn_in) {

      $output_produced_ok = true;

      $fcheck = @fopen($fn_in, "r");
      if ($fcheck === false) {
         print "cannot open file   $fn_in" . PHP_EOL;
         exit(2);
      }

      $fn_in = stream_get_meta_data($fcheck)["uri"];
      fclose($fcheck);

      $g->fn_in_short = basename($fn_in);

      if (isset($g->output_override_folder)) {
         @mkdir($g->output_override_folder);
         $fn_out = $g->output_override_folder . DIRECTORY_SEPARATOR . $g->fn_in_short;
      }
      else {
         $fn_out = $fn_in;
      }

      $g->fn_out_short = basename($fn_out);

      $g->base_dir = dirname($fn_in) . DIRECTORY_SEPARATOR;

      $pad_len = $g->show_in_filename_short ? 45 : 70;

      $opening_msg = '  ' . str_pad($g->fn_in_short, $pad_len, ' ') . '  ';

      print $opening_msg; // NO PHP_EOL

      $orig_data = file_get_contents($fn_in); // read in source html file
      // (any UTF8 text file)

      $CR = chr(13); // strip any win style crs

      $out_ins = str_replace($CR, "", $orig_data);

      $out_ins = insert_files_parse($out_ins); // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

      // $out_ins is always valid - if there were any problems we would have called exit(2)

      // do they want the NOT RECOMENDED pling to at for suits
      $pling_2_at = (strpos($out_ins, PLING2AT) !== false);
      if ($pling_2_at) {
         $out_ins = str_ireplace('!S', '@s', $out_ins);
         $out_ins = str_ireplace('!H', '@h', $out_ins);
         $out_ins = str_ireplace('!D', '@d', $out_ins);
         $out_ins = str_ireplace('!C', '@c', $out_ins);
      }

      $out_pg = pg_numbering_parse($out_ins, $pg_parse_success);

      $same_after_ins = (strcmp($orig_data, $out_ins) == 0); // == 0 tests

      $same_after_both = (strcmp($orig_data, $out_pg) == 0); // == 0 tests for equality

      if ($pg_parse_success) {
         $write_ins = false;
         if (isset($g->output_override_folder)) {
            $write_pg = true;
         }
         elseif ($same_after_both) {
            $write_pg = false;
         }
         else {
            $write_pg = true;
         }
      }
      else {
         $write_pg = false;
         if (isset($g->output_override_folder)) {
            $write_ins = true;
         }
         elseif ($same_after_ins) {
            $write_ins = false;
         }
         else {
            $write_ins = true;
         }
      }

      if ($write_ins) {
         $fo = fopen($fn_out, 'w'); // create the outputfile
         fwrite($fo, $out_ins);
         fclose($fo);
      }
      elseif ($write_pg) {
         $fo = fopen($fn_out, 'w'); // create the outputfile
         fwrite($fo, $out_pg);
         fclose($fo);
      }

      if ($same_after_both) {
         $out_disp = "- no changes made -";
      }
      elseif ($pg_parse_success === false) {
         $out_disp = '       ' . ' STOPPING';
         // any alignment issues will already be showing above
      }
      else {
         $fld = isset($g->output_override_folder) ? $g->output_override_folder . ' ... ' : '';
         $out_disp = '=>  ' . $fld . $g->fn_out_short;
      }

      print "$out_disp" . PHP_EOL;

      if ($pg_parse_success === false) {
         exit(2);
      }
   }
}

/*
 *
 */
// ==================================================
function insert_files_parse ($caller_data)
{
   global $g;

   $data = $caller_data;

   $start_at = 0;

   while (true) {

      $from_pos = '';
      $fn_inc_short = rpf_findValue($data, INSERT_START, $from_pos, $start_at);

      if ($fn_inc_short == '') {
         return $data;
      }

      $fcheck = @fopen($g->base_dir . $fn_inc_short, "r");
      if ($fcheck === false) {
         print PHP_EOL . "Cannot open  INSERT_START  file   $fn_inc_short   in folder  $g->base_dir";
         print PHP_EOL . ' STOPPING' . PHP_EOL;
         exit(2);
      }

      // print " Parse - found header start = " . $fn_inc_short . PHP_EOL;

      $end_marker = INSERT_END . $fn_inc_short;

      $end_pos = get_pos_of_eol_before($data, $end_marker);

      if ($end_pos < 0) {
         print PHP_EOL . "NO matching  INSERT-END**  for  $fn_inc_short  was found in  $g->fn_in_short";
         print PHP_EOL . ' STOPPING' . PHP_EOL;
         exit(2);
      }

      $start_at = $from_pos;

      // ===================================================
      /*
       * Get extaract and vaildate the 'insert file' text
       */
      $fn_inc_long = stream_get_meta_data($fcheck)["uri"];
      fclose($fcheck);

      $in = file_get_contents($fn_inc_long); // read in source insert file

      $in = str_replace(chr(13), "", $in); // CR's are restored if wanted later

      $from = get_pos_of_eol_after($in, BEFORE_EXC);

      if ($from < 1) {
         print PHP_EOL . 'No  ' . BEFORE_EXC . "  in file   $fn_inc_short   in folder $g->base_dir";
         print PHP_EOL . ' STOPPING' . PHP_EOL;
         exit(2);
      }

      $to = get_pos_of_eol_before($in, AFTER_EXC);

      if ($to < 1) {
         print PHP_EOL . 'No  ' . AFTER_EXC . "  in file   $fn_inc_short   in folder  $g->base_dir";
         print PHP_EOL . ' STOPPING' . PHP_EOL;
         exit(2);
      }

      $length = $to - $from;

      if ($length > 0)
         $in = substr($in, $from, $length);
      else
         $in = "";

      $data = substr($data, 0, $from_pos) . $in . substr($data, $end_pos);
   }
}

/*
 *
 */
// ==================================================
function pg_numbering_parse ($caller_data, &$output_produced_ok)
{
   global $g;

   $pageCount = 0; // the first page of a lin file is numbered 0 (zero) and not
   // displayed
   $lc_in = 1; // lines are numbered from 1 because that is what most editors
   // do.

   $CR = chr(13);
   $LF = chr(10);

   if ($g->EOL_choice == 'LF') {
      $eol = $LF;
      $discard_CR = true;
   }
   else {
      $eol = $CR . "" . $LF;
      $discard_CR = false;
   }

   $data = $caller_data . '  '; // extra spaces to make the parsing easier;

   $state = 'cmd'; // we start in command huntting mode

   $out = '';

   $in_pg_data = false;
   $pg_count = 0;

   $x = ''; // trying to detect when the lin file is out of alignment
   $a = '';
   $b = $data[0];
   $c = $data[1];

   if ($b == $LF) {
      $lc_in ++;
   }

   if ($c == $LF) {
      $lc_in ++;
   }

   $output_produced_ok = true;
   $alignment_issues = 0;

   // the new on off machansim

   $NEAR_char = chr(02);
   $STD_char = chr(03);

   $NEAR_STR__seen_in_file = (strpos($data, NEAR_STR) !== false);

   if ($NEAR_STR__seen_in_file) {
      $data = str_replace(STD_STR, $STD_char, $data);
      $data = str_replace(NEAR_STR, $NEAR_char, $data);
   }

   $data_len = strlen($data);

   $mode_near = true;

   /*
    * The MAIN loop checking each character
    * =====================================
    */
   for ($i = 2; $i < $data_len; $i ++) {

      $x = $a;
      $a = $b;
      $b = $c;
      $c = $data[$i];

      if ($c == $LF) {
         $lc_in ++;
      }
      elseif ($c == $NEAR_char) {
         $mode_near = false;
      }
      elseif ($c == $STD_char) {
         $mode_near = true;
      }

      if ($in_pg_data) {
         if ($c == '|') {
            if ($mode_near) {
               // skip all cr lf that are ahead of us
               while (true) {
                  if ($data[$i + 1] == $CR || $data[$i + 1] == $LF) {
                     if ($data[$i + 1] == $LF) {
                        $lc_in ++;
                     }
                     $i ++;
                     continue;
                  }
                  break;
               }
               $out .= '|' . $eol . $eol . $eol;
            }
            else {
               $out .= '|';
            }

            $a = '';
            $b = '';
            $c = '';
            $in_pg_data = false;

            $state = 'cmd';
         }
         continue; // so discarding the current c$
      }

      if (($state == 'cmd') && ($c == '|')) {

         if ((! empty($x)) && ($x != '|') && ($x != $LF)) {
            $p = 0;
            for (; $p < 40; $p ++) {
               if ($data[$i - ($p + 1)] == $LF)
                  break;
            }
            $seg = substr($data, $i - $p, $p + 1);

            print PHP_EOL . ' Line ' . str_pad($lc_in, 5) . '  pg ' . str_pad($pg_count, 5) . ' alignment ?   ' . $seg;

            $output_produced_ok = false; // we are only hunting for errors
            // from now on - no output

            $alignment_issues ++;
            if ($alignment_issues >= 5) {
               break; // end and quit
            }

            $in_pg_data = false;
            continue; // as we suspect we are wrongly in 'cmd' mode we stay
            // in 'cmd' as it should now be correct
         }

         if (($a == 'p' || $a == 'P') && ($b == 'g' || $b == 'G')) { // pg

            $in_pg_data = true;
            while (true) { // strip existing CR's and LF's so multi pg's
               // comeout togeater
               $ol = strlen($out) - 1;
               if ($out[$ol] == $CR || $out[$ol] == $LF) {
                  $out = substr($out, 0, $ol);
                  continue;
               }
               break;
            }

            if ($mode_near) {
               $out .= $eol . $a . $b . '| ***** ' . $pg_count . ' ***** ';
            }
            else {
               $out .= $a . $b . '|';
            }

            $pg_count ++;

            $a = '';
            $b = '';
            $c = ''; // to suppress the bar output
         }
         else
            if (($a == 'l' || $a == 'L') && ($b == 'b' || $b == 'B')) {
               $pg_count ++;
            }

         $state = 'data';
      }
      else
         if ($state == 'data' && ($c == '|')) {
            $state = 'cmd';
            $in_pg_data = false;
         }

      if ($in_pg_data) {
         continue; // pg data is ALWAYS discarded and replaced with a newly
         // generated pg number
      }

      if ($discard_CR) { // we are mac / unix
         if ($a == $CR) {
            $a = '';
         }
      }
      else { // we want windows output
         if ($a == $LF && $x != $CR) {
            $out .= $CR;
         }
      }
      $out .= $a;
   }

   if ($NEAR_STR__seen_in_file) {
      $out = str_replace($STD_char, STD_STR, $out);
      $out = str_replace($NEAR_char, NEAR_STR, $out);
   }

   return $out;
}

// ==================================================
function rpf_findValue ($data, $marker, & $rtn_to, $start_at = 0)
{
   $lenMarker = strlen($marker);

   $from = strpos($data, $marker, $start_at);

   if ($from <= 0)
      return '';

   $from += $lenMarker;

   $to = strpos($data, "\n", $from);

   if ($to <= 0)
      return '';

   $rtn_to = $to + strlen("\n"); // to skip the next line character

   return substr($data, $from, $to - $from);
}

// ==================================================
function get_pos_of_eol_after ($data, $marker)
{
   $from = strpos($data, $marker);

   if ($from <= 0) {
      return - 1;
   }

   $from2 = strpos($data, "\n", $from);

   return $from2 + 1;
}

// ==================================================
function get_pos_of_eol_before ($data, $marker)
{
   $at = strpos($data, $marker);

   if ($at <= 0) {
      return - 1;
   }

   $at2 = strrpos($data, "\n", $at - strlen($data));

   return $at2;
}



