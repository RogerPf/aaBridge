<?php
error_reporting(E_ALL);

main();

exit(0);

// ****************************************************************************
function main()
{
    $version = "2.51";
    $date_last_changed = "2020 Jun 07";

    if (version_compare(phpversion(), '7.0.0', '<')) {
        date_default_timezone_set('America/New_York');
    }

    $app_text = " ";

    global $LF;
    global $CR;
    global $our_EOL;

    $LF = chr(10);
    $CR = chr(13);
    $our_EOL = (substr(PHP_OS, 0, 3) === 'WIN') ? $CR . $LF : $LF;
    if (file_exists("C:/ProgramSmall/aaBridge/aaBridge__aaa_use_LF.txt")) {
        $our_EOL = $LF;
    }

    global $dealer_script_marker;
    global $merge_list_marker;
    global $seat_kib_marker;

    $dealer_script_marker = "zd";
    $merge_list_marker = "zg";
    $seat_kib_marker = "sk";

    global $mi_force_silent;
    $mi_force_silent = false;

    global $argv;
    global $z_out_and_stop;

    global $current_app_name;

    $current_app_name = pathinfo($argv[0], PATHINFO_FILENAME);
    $z_out_and_stop = false;

    global $current_app_name_and_ver;
    $current_app_name_and_ver = $current_app_name . " (v$version)";

    /*
     * for each supplied argument "glob" it
     * and for each valid dm_list file
     * call deal and then the merge as appropriate
     */

    $has_orig_args = false;

    $dm_lists_ay = array();
    $sc_list = array();

    $first = true;
    $dm_list_seen = false;
    $txt_seen = false;
    $sc_list_seen = false;

    // check for dm-list searches
    for ($u = 1; isset($argv[$u]); $u ++) {
        $v = $argv[$u];
        if (strToLower($v) === 'no_pause')
            continue;
        $has_orig_args = true;
        if (endsWith($v, '.dm-list')) {
            $dm_list_seen = true;
            break;
        }
    }

    // check for txt searches
    if ($dm_list_seen === false) {
        for ($u = 1; isset($argv[$u]); $u ++) {
            $v = $argv[$u];
            if (strToLower($v) === 'no_pause')
                continue;
            $has_orig_args = true;
            if (endsWith($v, '.txt')) {
                $sc_list_seen = true;
                break;
            }
        }
    }

    if ($has_orig_args === false || $dm_list_seen) {

        if ($has_orig_args === false) {
            $argv['1'] = '*.dm-list';
        }

        for ($u = 1; isset($argv[$u]); $u ++) {
            $v = $argv[$u];

            $ext = '.dm-list';
            $len = strlen($ext);

            if ((strlen($v) > $len) && substr(strtolower($v), - $len) === $ext) {
                $v = substr($v, 0, - $len) . '.dm-list';
            }

            $glob2 = glob($v);
            usort($glob2, "order_RPf");

            foreach ($glob2 as $fn) {
                if ((strlen($fn) < $len) || (substr(strtolower($fn), - $len) != $ext)) {
                    continue;
                }
                $dm_lists_ay[] = $fn;
            }
        }
    }

    if (count($dm_lists_ay) === 0 && $dm_list_seen === false) { // no dm_list enq seen so look for .txt (scripts)

        if ($has_orig_args == false) {
            $argv['1'] = '*.txt';
        }

        for ($u = 1; isset($argv[$u]); $u ++) {
            $v = $argv[$u];

            $ext = '.txt';
            $len = strlen($ext);

            if ((strlen($v) > $len) && substr(strtolower($v), - $len) === $ext) {
                $v = substr($v, 0, - $len) . '.txt';
            }

            $glob2 = glob($v);
            usort($glob2, "order_RPf");

            foreach ($glob2 as $fn) {
                if ((strlen($fn) < $len) || (substr(strtolower($fn), - $len) != $ext)) {
                    continue;
                }
                $sc_list[] = $fn;
            }
        }

        if (count($sc_list) > 0) {
            // push the extra commands on to the FRONT of the array
            if (count($sc_list) == 1) {
                $z_out_and_stop = true;
                $mi_force_silent = true;
            }
            else {
                // print PHP_EOL;
                print "$current_app_name_and_ver     date last updated     $date_last_changed" . PHP_EOL;
                print "   ---- " . PHP_EOL;
            }

            array_unshift($sc_list, "-merge: n");
            array_unshift($sc_list, "-verbose: n");

            process_dm_list("", $sc_list);

            if (count($sc_list) == 1) {
                exit(0);
            }
        }
    }

    if (count($dm_lists_ay) === 0 && count($sc_list) === 0) {

        if (count($dm_lists_ay) == 0) {
            // print PHP_EOL;
            print "$current_app_name_and_ver     date last updated     $date_last_changed     (PHP ver " . phpversion() . ')' . PHP_EOL;
            print "No matching    .dm-list  extension    file(s) found                usage..." . PHP_EOL . PHP_EOL;
            print "       $current_app_name   <fname>.dm-list    inc wild cards,  defaults to    *.dm-list" . PHP_EOL . PHP_EOL;
            print "See the   aBridge   Doc collection   aadm_package__vN.NN.zip   for docs" . PHP_EOL;
            print PHP_EOL;
            exit(2);
        }
    }

    // print PHP_EOL;
    print "$current_app_name_and_ver     date last updated     $date_last_changed" . PHP_EOL;
    print "   ---- " . PHP_EOL;

    if (count($dm_lists_ay) > 0) {

        foreach ($dm_lists_ay as $list_name) {

            if (count($sc_list) > 0) {
                unshift($list_name, "-show_banner:");
            }

            process_dm_list($list_name, null);

            $z = "";
        }
    }
}

// =====================================================================================
function order_RPf($a, $b)
{
    $f = array(
        '_',
        ' '
    );
    return strcmp(str_replace($f, '0', $a), str_replace($f, '0', $b));
}

// =====================================================================================
function remove_mrg_from_name(&$name)
{
    if (($p = strrpos(strtolower($name), "mrg")) < 2)
        return;

    while ($p > 1) {
        if ($name[$p - 1] !== '_')
            break;
        $p --;
    }

    $name = substr($name, 0, $p);
}

// =====================================================================================
function extract_kibseat___default_south(&$name)
{
    $sk = 'S';

    $p = strlen($name);
    while ($p > 2) {
        if ($name[$p - 1] !== '_')
            break;
        $p --;
    }
    $name = substr($name, 0, $p);

    if ($p < 3)
        return $sk;

    if ($name[$p - 2] !== '_')
        return $sk;

    $c = strtoUpper($name[$p - 1]);

    if ($c === 'N' || $c === 'E' || $c === 'W' || $c === 'S') {
        $sk = $c;
    }
    else {
        return $sk;
    }

    $p --;
    while ($p > 2) {
        if ($name[$p - 1] !== '_')
            break;
        $p --;
    }
    $name = substr($name, 0, $p);

    return $sk;
}

// =====================================================================================
function process_dm_list($list_name_p, $dm_array_p)
{
    // Process the deal merge list supplied on the command line
    $dmListName = $list_name_p;

    global $LF;
    global $CR;
    global $our_EOL;

    global $copy3_fld;
    global $dealer_to_cp3;
    $copy3_fld = "";
    $dealer_to_cp3 = false;

    $do_copy1 = true;
    $do_copy2 = true;
    $do_copy3 = true;

    // loadSpecialSettings();

    global $max_limit;
    global $merge;

    global $random_selection;
    global $pbn_folder_path;
    global $pbn_folder_path_display;

    $max_limit = 64;

    global $qMaster;
    $qMaster = new QMaster();

    $first = true;

    $random_selection = true;
    $newBoardNumber = 1;

    $pbn_folder_path_display = "pbns";
    $pbn_folder_path = "pbns/";
    $op_core_fname = "";

    $PBN_files = array();

    $out = "";

    $dmList = array();

    static $showBanner = false;

    $banner_count = 0;

    if ($dmListName !== "") {

        $len = strlen($dmListName);

        $mg_merge_id = pathinfo($dmListName, PATHINFO_FILENAME);

        remove_mrg_from_name($mg_merge_id);

        $op_core_fname = $mg_merge_id;

        $dmList = @file($dmListName, FILE_IGNORE_NEW_LINES);

        $base = dirname($dmListName);

        if (isset($dm_array_p)) {
            $dmList = array_merge($dmList, $dm_array_p);
        }

        $show_banner = false;

        foreach ($dmList as $line) {
            $com = "-show_banner:";
            if (startsWith($line, $com)) {
                $show_banner = startsWith(strtolower(trim(substr($line, strlen($com)))), 'y');
                break;
            }
        }

        if ($show_banner) {
            // if ($banner_count ++ > 0) {
            print PHP_EOL;
            // }
            print ">>> " . (str_pad("", 74, "- - - - - - ")) . " <<<" . PHP_EOL;
            print ">>> " . (str_pad($dmListName, 74, " ", STR_PAD_BOTH)) . " <<<" . PHP_EOL;
            print ">>> " . (str_pad("", 74, "- - - - - - ")) . " <<<" . PHP_EOL;
            print PHP_EOL;
        }

        print pad_A("Deal Merge list: ") . $dmListName . PHP_EOL;
        print "   ----" . PHP_EOL;

        chdir($base);
    }
    else {
        $dmList = $dm_array_p;
    }

    global $do_merge;
    global $verbose;
    global $comments_wanted;

    $do_merge = true;
    $verbose = true;
    $smp = false;
    $comments_wanted = false;

    $ratioToTake = 1;

    $first = 0;

    $smp = false; // some config line has been printed ?

    foreach ($dmList as $line) {

        $line = trim($line);

        if ($line === "") {
            continue;
        }
        $c = substr($line, 0, 1);

        if ($c === "#") {
            continue;
        }

        if ($c === "-") {
            $com = "";
            $ch = "";
            $value = "";
            $comment = "";

            explode_cmd($line, $com, $ch, $value, $comment);

            $cmd = "-verbose:";
            if ($cmd === $com) {
                $verbose = ($ch !== 'n');
                if ($verbose) {
                    $smp = true;
                    print pad_cmd($cmd, ($verbose ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                }
                continue;
            }

            $cmd = "-show_banner:";
            if ($cmd === $com) {
                // has already been read and set
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($show_banner ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-show_comments:";
            if ($cmd === $com) {
                $comments_wanted = ($ch !== 'n');
                if ($verbose) {
                    print pad_cmd($cmd, ($comments_wanted ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                }
                continue;
            }

            $cmd = "-pbn_folder:";
            if ($cmd === $com) {
                $pbn_folder_path = path_to_nix(pathinfo($value, PATHINFO_FILENAME));
                if (empty($pbn_folder_path)) {
                    $pbn_folder_path = "pbns";
                }
                $smp = $verbose;
                if ($verbose) {
                    print pad_cmd($cmd, $pbn_folder_path, $comment, $comments_wanted) . PHP_EOL;
                }
                $pbn_folder_path_display = $pbn_folder_path;
                $pbn_folder_path .= "/";
                continue;
            }

            // $cmd = "-del_pbn_folder:";
            // if ($cmd === $com) {
            // $delete_it = ($ch === 'y');
            // if ($verbose) {
            // print pad_cmd($cmd, ($delete_it ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
            // }
            // if ($delete_it) {
            // rrmdir($pbn_folder_path);
            // }
            // continue;
            // }

            $cmd = "-merge:";
            if ($cmd === $com) {
                $do_merge = ($ch !== 'n');
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($do_merge ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-copy1:";
            if ($cmd === $com) {
                $do_copy1 = ($ch !== 'n');
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($do_copy1 ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-copy2:";
            if ($cmd === $com) {
                $do_copy2 = ($ch !== 'n');
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($do_copy2 ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-copy3:";
            if ($cmd === $com) {
                $do_copy3 = ($ch !== 'n');
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($do_copy3 ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-dealer_to_cp3:";
            if ($cmd === $com) {
                $dealer_to_cp3 = ($ch === 'y');
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($dealer_to_cp3 ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-random:";
            if ($cmd === $com) {
                $random_selection = ($ch !== 'n');
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($random_selection ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-max_to_merge:";
            if ($cmd === $com) {
                $max_limit = trim($value);
                $smp = $verbose;
                if ($verbose)
                    print pad_cmd($cmd, ($max_limit ? "Yes" : "No"), $comment, $comments_wanted) . PHP_EOL;
                continue;
            }

            $cmd = "-3rd_copy_fld:";
            if ($cmd === $com) {
                $copy3_fld = path_to_nix($value);
                if (! empty($copy3_fld)) {
                    if (endsWith($copy3_fld, '/') == false) {
                        $copy3_fld .= "/";
                    }
                }
                $smp = $verbose;
                if ($verbose) {
                    print pad_cmd($cmd, $copy3_fld, $comment, $comments_wanted) . PHP_EOL;
                }
                if (! empty($copy3_fld)) {
                    if (file_exists($copy3_fld) === false) {
                        @mkdir($copy3_fld); // mode is the 2nd param it defaults to 0777
                        if (file_exists($copy3_fld) === false) {
                            print PHP_EOL . "   STOPPING  - Failed to create    3rd Copy folder   $copy3_fld" . PHP_EOL . PHP_EOL;
                            exit(2);
                        }
                    }
                }
                continue;
            }

            print PHP_EOL . "STOPPING  >>>     $line     <<< not understood, is NOT a valid setting" . PHP_EOL;
            exit(2);
        }

        if ($first ++ == 0) {
            if ($smp)
                print "   ---- " . PHP_EOL;
        }

        // we assume that if we are here then it is an INPUT file

        $c2 = substr($line, 1, 1);
        if ($c2 === " " || $c2 === "\t") { // i.e. test the second character
            $ratioToTake = substr($line, 0, 1);
            if (($ratioToTake === '-') || ($ratioToTake + 0 == 0)) {
                $ratioToTake = 0;
            }
            $line = trim(substr($line, 1));
        }

        $fname = path_to_nix($line);

        global $pbn_folder_path;

        $PBN_files[] = new PBN_file($qMaster, $fname, $ratioToTake, $pbn_folder_path, $verbose);
    }

    if (sizeof($PBN_files) == 0) {
        print PHP_EOL . "STOPPING - No script file entries found !" . PHP_EOL . PHP_EOL;
        exit(0);
    }

    // ---------------------------------------
    if ($dmListName !== "") {
        print PHP_EOL . "Deal Phase" . PHP_EOL;
    }

    foreach ($PBN_files as $index => $entry) {

        $entry->dealOrRead(); // <<<<<<<<<<<<<<<<<<<<<<<< DEAL DEAL DEAL <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        ;
    }

    // ---------------------------------------

    if ($do_merge == false) {
        print "  -----" . PHP_EOL . "Done - 'No merge' was set -  look in  $pbn_folder_path_display" . PHP_EOL . PHP_EOL;
        exit(0);
    }

    print PHP_EOL . "Merge Phase" . PHP_EOL;

    $prefix = "yy___";
    $postfix = "_mrg";
    $ext = ".pbn";

    global $copy3_fld;

    $name_1st_copy = "./" . $prefix . $op_core_fname . $postfix . $ext;
    $name_2nd_copy = $pbn_folder_path . $op_core_fname . $postfix . $ext;
    $name_3rd_copy = $copy3_fld . $op_core_fname . $postfix . $ext;

    global $random_selection;
    global $max_limit;

    $qMaster->merge($random_selection, $max_limit);

    if ($qMaster->countQueues() === 0) {
        print PHP_EOL . "  STOPPING   -   No pbn files supplied   or   ALL valid pbn files have been excluded" . PHP_EOL . PHP_EOL;
        exit(2);
    }

    $out = "";

    $qMaster->writeMergedToOutString($out, $op_core_fname . $postfix . ".dm-list");

    // Show the user how many of what were taken
    print " Avail Took Ratio" . PHP_EOL;

    foreach ($PBN_files as $sFile) {

        $avail = padded3($sFile->getCount(), false);
        $taken = padded3($sFile->getNumberTaken(), $sFile->ratioToTake + 0 == 0);
        $to_take = padded3($sFile->ratioToTake, true);

        print "  $avail  $taken $to_take  " . pathinfo($sFile->fname, PATHINFO_BASENAME) . PHP_EOL;
    }

    // write the merged file ========================================================

    print PHP_EOL . "Writing the merged pbn file" . PHP_EOL;

    // copy 1 is written to the working folder ie: where the scripts are
    $name = $name_1st_copy;
    print "  -----" . PHP_EOL;
    print (str_pad("  copy1   $name", 60)) . PHP_EOL;
    if ($do_copy1) {
        write_big_str_to_file($name, $out);
    }

    // copy 2 is written to the pbn folder
    $name = $name_2nd_copy;
    print (str_pad("  copy2   $name", 60)) . PHP_EOL;
    if ($do_copy2) {
        write_big_str_to_file($name, $out);
    }

    // copy 3 is written to the 3rd copy folder
    if ($do_copy3 && ! empty($copy3_fld)) {
        $name = $name_3rd_copy;
        print (str_pad("  copy3   $name", 60)) . PHP_EOL;
        if ($do_copy3) {
            write_big_str_to_file($name, $out);
        }
    }

    print "  -----" . PHP_EOL . "Done - for other dealt  pbn  flies look in   $pbn_folder_path_display" . PHP_EOL . PHP_EOL;
}

/**
 * ****************************************************************************
 */
function write_big_str_to_file($fname, $out)
{
    $fout = fopen($fname, 'w'); // create the outputfile which will overwrite any existing file.
    fwrite($fout, $out);
    fclose($fout);
}

// /**
// * ****************************************************************************
// */
// function print_usage_and_exit ()
// {
// print "Usage: " . PHP_EOL . PHP_EOL;
// print " $current_app_name -f <deal-and-merge_list.txt> " . PHP_EOL;
// print "" . PHP_EOL;

// print "inside <deal-and-merge_list.txt> you can have / need the following lines" . PHP_EOL;
// print "" . PHP_EOL;

// print " TO BE COMPLETED " . PHP_EOL;
// print "" . PHP_EOL;
// print " -r = select the deals randomly. [OPTIONAL]" . PHP_EOL;
// print " " . PHP_EOL;
// print " -m numb = numb is Maximum number of deals to merge in total. [default 64]" . PHP_EOL;
// print " -o fname = fname is the output file name." . PHP_EOL;
// print " digit = the ratio of deals to be read from that pbn file. [OPTIONAL]" . PHP_EOL;
// print " file = name of a .pbn file to merge." . PHP_EOL;
// print " -f <merge_List> = the name of a text file containing the details of the merge." . PHP_EOL;
// print " That file can start with -r and/or -m numb" . PHP_EOL . PHP_EOL;

// print " DO NOT use SPACES in any filenames, use underscore '_' instead." . PHP_EOL . PHP_EOL;

// print " Examples: " . PHP_EOL . PHP_EOL;

// print " The output .pbn file will have a name starting with " . $namePrefix . PHP_EOL . PHP_EOL;

// exit(0);
// }

/**
 * ****************************************************************************
 */
class QMaster
{
    public $dealQueues = array();
    public $merged = array();

    public function countQueues()
    {
        return count($this->dealQueues);
    }

    public function addQueue($dealQueue)
    {
        $this->dealQueues[] = $dealQueue;
    }

    public function merge($random_selection, $max_limit)
    {
        $total = 0;

        while (true) {

            $found = false;

            foreach ($this->dealQueues as $dealQueue) {
                if ($dealQueue->takeNext()) {
                    $found = true;
                    $total ++;
                    if ($total == 1) {
                        // always write the first one out at once - for the embedded name
                        $this->merged[] = $dealQueue->getAndClearTaken();
                    }
                    if ($total >= $max_limit)
                        break;
                }
            }

            if ($found == false)
                break;

            if ($random_selection) {
                // three times just for fun :)
                shuffle($this->dealQueues);
                shuffle($this->dealQueues);
                shuffle($this->dealQueues);
            }

            foreach ($this->dealQueues as $dealQueue) {
                if ($dealQueue->isTakenValid()) {
                    $this->merged[] = $dealQueue->getAndClearTaken();
                }
            }

            if ($total >= $max_limit)
                break;
        }
    }

    public function writeMergedToOutString(&$out, $dmListName)
    {
        $new_number = 0;
        foreach ($this->merged as $pbn) {
            $new_number ++;
            $pbn->writeDealToStr($out, $dmListName, $new_number, /* first */ ($new_number === 1));
        }
    }
}

/**
 * ****************************************************************************
 */
class Pbn
{
    public $orig_lin_or_pbn_name;
    public $pbnLines;
    public $local_pbns_out;
    public $zd_dealer_cname;
    public $zg_merge_cname;
    public $sk_value;

    function __construct($pbnLines, $local_pbns_out, $orig_lin_or_pbn_name_p)
    {
        global $dealer_script_marker;
        global $merge_list_marker;
        global $seat_kib_marker;

        $this->pbnLines = $pbnLines;
        $this->local_pbns_out = $local_pbns_out;
        $this->orig_lin_or_pbn_name = $orig_lin_or_pbn_name_p;

        $this->dm_list_name = '';
        $this->dealscr_name = '';

        $this->zd_dealer_cname = '';
        $this->zg_merge_cname = '';
        $this->sk_value == '';

        foreach ($this->pbnLines as $key => $line) {

            $ds_original = "";

            if (substr($line, 0, 6) == '[Event') {
                // Event - try to extract the Original Dealer script name
                static $seed_marker = ', seed';
                static $dealer_marker = 'simulated by dealer with file';

                $seedPos = strrpos($line, $seed_marker);
                $dealer_marker_len = strlen($dealer_marker);
                $startPos = strpos($line, $dealer_marker) + $dealer_marker_len;

                if (($startPos > $dealer_marker_len) && ($seedPos > $startPos)) {
                    $ds_orig = trim(substr($line, $startPos, $seedPos - $startPos));
                    // $line = '[Event "-"]';
                    $this->pbnLines[$key] = $line;
                    $ds_ext = pathinfo($ds_orig, PATHINFO_EXTENSION);
                    $ds_orig = trim(pathinfo($ds_orig, PATHINFO_FILENAME)); // remove the extension
                    $this->sk_value = extract_kibseat___default_south($ds_orig); // ds_orig also changed
                    $this->zd_dealer_cname = $ds_orig . (empty($ds_ext) ? "" : "." . $ds_ext);
                }
                else {
                    $this->zd_dealer_cname = extract_marked_item($line, $dealer_script_marker, false);
                }
            }

            elseif (substr($line, 0, 5) == '[Site') {
                // Site
                $mg = extract_marked_item($line, $merge_list_marker, true);
                if (empty($this->zg_merge_cname)) {
                    $this->zg_merge_cname = $mg;
                }

                $sk = extract_marked_item($line, $seat_kib_marker, false);
                if (empty($this->sk_value)) {
                    $this->sk_value = $mg;
                }
            }
            $z = 0;
        }
    }

    function writeDealToStr(&$out, $dmListName, $new_number, $first)
    {
        global $our_EOL;

        global $current_app_name;

        global $dealer_script_marker;
        global $merge_list_marker;
        global $seat_kib_marker;

        foreach ($this->pbnLines as $line) {

            if (substr($line, 0, 6) == '[Event') {

                $line = '[Event "';

                if (! empty($this->zd_dealer_cname)) {
                    $line .= make_maked_item($this->zd_dealer_cname, $dealer_script_marker);
                }
                elseif (! empty($this->orig_lin_or_pbn_name)) {
                    $line .= make_maked_item($this->orig_lin_or_pbn_name, $dealer_script_marker);
                }
                else {
                    $z = 0;
                }

                $line .= '"]';
            }

            elseif (substr($line, 0, 5) == '[Site') {

                $info = '';
                if (! empty($this->sk_value)) {
                    $info .= make_maked_item(strtoupper($this->sk_value), $seat_kib_marker);
                }

                $val = $dmListName; // $this->zg_merge_cname;
                if ($first && ! empty($val)) {
                    /*
                     * notice we save the CURRENT dmListName
                     * NOT with the name (if any) that we retreived from this deal
                     */
                    // $info .= make_maked_item($this->zg_merge_cname, $merge_list_marker);
                    $info .= make_maked_item($val, $merge_list_marker);
                }
                if ($info === '') {
                    $info = '-';
                }
                $line = '[Site "' . $info . '"]';
            }

            elseif ((substr($line, 0, 6) === '[Board') && $new_number > 0) {

                $line = '[Board "' . $new_number . '"]';
            }

            $out .= $line . $our_EOL;
        }

        $out .= $our_EOL;
    }
}

/**
 * ****************************************************************************
 *
 * @author roger
 *
 */
class DealQueue
{
    public $pbnFile;
    public $taken;

    function __construct($pbnFile)
    {
        $this->pbnFile = $pbnFile;
        $this->taken = null;
    }

    function takeNext()
    {
        $this->taken = $this->pbnFile->takeNext();
        return $this->taken != null;
    }

    function isTakenValid()
    {
        return $this->taken != null;
    }

    function getAndClearTaken()
    {
        $pbn = $this->taken;
        $this->taken = null;
        return $pbn;
    }
}

/**
 * ****************************************************************************
 *
 * @author roger
 *
 */
class PBN_file
{
    public $fname = "";
    public $local_pbns_out = "";
    public $ratioToTake = 1;
    public $nextToTake = 0;
    public $rawPbns = array();
    public $pbns = array();
    public $qMaster;

    function takeNext()
    {
        if ($this->nextToTake >= count($this->pbns))
            return null;

        return $this->pbns[$this->nextToTake ++];
    }

    function getCount()
    {
        return count($this->pbns);
    }

    function getNumberTaken()
    {
        return $this->nextToTake;
    }

    function __construct(&$qMaster, $fname, $ratioToTake, $local_pbns_out, $verbose_p)
    {
        $this->ext = strtolower(pathinfo($fname, PATHINFO_EXTENSION));

        if (($this->ext !== "txt") && ($this->ext != "pbn")) {
            print "  File   $fname   does not end with    .txt   OR   .pbn" . PHP_EOL;
            exit(2);
        }

        $this->qMaster = $qMaster;
        $this->fname = $fname;
        $this->local_pbns_out = $local_pbns_out;
        $this->ratioToTake = $ratioToTake;

        $CR = chr(13);
        $LF = chr(10);

        $to_take = $ratioToTake;
        if ($to_take == 0)
            $to_take = "-";
        // if ($to_take == 1)
        // $to_take = " ";

        $s = "  file_in:   " . $to_take . "  " . $fname;

        if ($verbose_p)
            print str_pad($s, 72) . (($this->ext === "pbn") ? "   <<< PBN" : "") . PHP_EOL;

        $file = @fopen($this->fname, "rb");
        if ($file === false) {
            print PHP_EOL . "STOPPING  -  Cannot open input file    " . $this->fname;
            print PHP_EOL . PHP_EOL;
            exit(2);
        }
        fclose($file);
    }

    /**
     * ****************************************************************************
     */
    function writeProcessedPbnsToFile($name, $renumber)
    {
        $out = "";
        $first = true;
        $new_number = 0;
        foreach ($this->pbns as $pbn) {
            if ($renumber)
                $new_number ++;
            $pbn->writeDealToStr($out, "", $new_number, $first);
            $first = false;
        }

        $fout = fopen($name, 'w'); // create the outputfile which will overwrite any existing file.
        fwrite($fout, $out);
        fclose($fout);
    }

    /**
     * ****************************************************************************
     */
    function writeRawPbnsToFile($fname)
    {
        global $LF;
        global $CR;

        $dealer_EOL = (substr(PHP_OS, 0, 3) === 'WIN') ? $CR . $LF : $LF;

        $pbnfout = @fopen($fname, 'w'); // create the pbn file
        if ($pbnfout == false) {
            print PHP_EOL . "STOPPING    problem writing to    $fname" . PHP_EOL;
            exit(2);
        }

        foreach ($this->rawPbns as $line) {
            fwrite($pbnfout, $line . $dealer_EOL);
        }
        fclose($pbnfout);
    }

    /**
     * ****************************************************************************
     *
     * dealorRead ()
     */
    function dealOrRead()
    {
        global $LF;
        global $CR;
        global $our_EOL;

        global $copy3_fld;
        global $dealer_to_cp3;

        global $z_out_and_stop;
        global $current_app_name_and_ver;

        $output = array();
        $ret_var = 0;
        $data = "";

        $save_dealer_copies_needed = false;

        if ($this->ext === "txt") {

            $real_exec = get_dealer_app() . '  "' . $this->fname . '"';

            $disp_exec = 'dealer  "' . $this->fname . '"';

            if ($z_out_and_stop) {
                print PHP_EOL . "$current_app_name_and_ver    dealer  $this->fname  >  z_out.pbn     ";

                $before = microtime( /* float */ true);
                $this->last_line = exec($real_exec, $this->rawPbns, $ret_var); // >>>>> EXECUTE the command -------------------------------------------------
                $time_taken = number_format((microtime( /* float */ true) - $before), 1 /* precision */
                );

                if ($ret_var !== 0)
                    exit(2);
                $this->writeRawPbnsToFile("z_out.pbn");
                print (str_pad($time_taken, 5, " ", STR_PAD_LEFT)) . " s  OK" . PHP_EOL;
                exit(0);
            }

            print str_pad("   ... $disp_exec", 69);

            $before = microtime( /* float */ true);
            $this->last_line = exec($real_exec, $this->rawPbns, $ret_var); // >>>>> EXECUTE the command -------------------------------------------------
            $time_taken = number_format((microtime( /* float */ true) - $before), 1 /* precision */
            );

            if ($ret_var != 0) {
                print PHP_EOL . "STOPPING - problem running:   $disp_exec    ^^^^ LOOK ^^^^" . PHP_EOL;
                print PHP_EOL;
                exit(2);
            }

            print ' ' . (str_pad(($time_taken), 5, " ", STR_PAD_LEFT)) . ' s';

            foreach ($this->rawPbns as $line) {
                $data .= $line . $LF; // yes this is and should be ONLY $LF
            }

            $save_dealer_copies_needed = true;
        }
        else {
            if ($this->ext != "pbn") {
                print "STOPPING    -   " . $this->fname . "    BUG !!!!   is not  pbn or txt";
                exit(2);
            }
            print "  read          " . $this->fname;

            $data = @file_get_contents($this->fname); // read in source file

            if (substr_count($data, '[') < 9) {
                print PHP_EOL . "No hands found in  $fs_in" . PHP_EOL;
                return;
            }
        }

        $data = str_ireplace($LF . $CR, $LF, $data, $v0);
        $data = str_ireplace($CR . $LF, $LF, $data, $v1);
        $data = str_ireplace($CR, $LF, $data, $v2);

        $raw_hands = explode($LF . $LF, $data);

        // remove and NON pbn debris at the end of the (read in) file
        while ((count($raw_hands) > 0) && (substr(end($raw_hands), 0, 1) != "[")) {
            array_pop($raw_hands);
        }

        foreach ($raw_hands as $raw_h) {

            $local_name = pathinfo($this->fname, PATHINFO_FILENAME) . "." . pathinfo($this->fname, PATHINFO_EXTENSION);

            // Create the pbn with all its file info inside it
            $this->pbns[] = new Pbn(explode($LF, $raw_h), $this->local_pbns_out, $local_name);
            ;
        }

        if (count($this->pbns) == 0) {
            print ' none dealt';
        }

        if ($save_dealer_copies_needed) {

            $fout_name = trim(pathinfo($this->fname, PATHINFO_FILENAME));

            $not_used = extract_kibseat___default_south($fout_name); // $fout_name also changed

            global $pbn_folder_path;

            @mkdir($pbn_folder_path); // mode 2nd param defaults to 0777

            $pbn_file_name = $pbn_folder_path . $fout_name . ".pbn";

            $this->writeProcessedPbnsToFile($pbn_file_name, false /* no renumber */
            );

            $done_3cpy = false;
            if ($dealer_to_cp3) {
                if (($copy3_fld !== "") && ($copy3_fld !== ".") && ($copy3_fld !== "/") && ($copy3_fld !== "./")) {

                    $fname_3cpy = $copy3_fld . pathinfo($fout_name, PATHINFO_FILENAME) . ".pbn";
                    $this->writeProcessedPbnsToFile($fname_3cpy, false /* no renumber */
                    );

                    print($done_3cpy ? "  > 3cp" : "");

                    $done_3cpy = true;
                }
            }
        }

        print PHP_EOL;

        // add ourselves to the master merge queue

        for ($i = 0; $i < $this->ratioToTake; $i ++) {
            $this->qMaster->addQueue(new dealQueue($this));
        }
    }
}

/**
 * ****************************************************************************
 */
function explode_cmd($line, &$com, &$ch, &$val, &$comments)
{
    $com = "";
    $ch = "";
    $val = "";
    $comments = "";

    if ($line === "")
        return;

    $parts = explode('#', $line, 2 /* two parts only */
    );

    // $com = strToLower(explode('\s', $line, 2)[0]);

    $first = preg_split('/(\s)/', $line);

    $com = $first[0];

    $val = trim(substr($parts[0], strlen($com)));

    if (! empty($val)) {
        $ch = strToLower(substr($val, 0, 1));
    }

    // $rest = isSet($res[2]) ? $res[2] : "";

    if (isset($parts[1])) {
        $comments = '#' . $parts[1]; // restoring any un space compressed bits
    }
}

/**
 * ****************************************************************************
 */
function addPbnIfNeeded($name)
{
    if (endsWith(strtoLower($name), ".pbn"))
        return $name;
    else
        return $name . ".pbn";
}

/**
 * ****************************************************************************
 */
function endsWith($str, $end)
{
    return substr(strToLower($str), - strlen($end)) === $end;
}

/**
 * ****************************************************************************
 */
function startsWith($str, $start)
{
    return strpos(strToLower($str), strToLower($start)) === 0;
}

/**
 * ****************************************************************************
 */
function padded3($s, $use_hyphen)
{
    if ($use_hyphen && $s + 0 == 0)
        $s = "-";
    if (strlen($s) == 0)
        return "   " . $s;
    if (strlen($s) == 1)
        return "  " . $s;
    if (strlen($s) == 2)
        return " " . $s;
    return $s;
}

/**
 * ****************************************************************************
 */
function pad_cmd($cmd, $value, $comment, $comments_wanted)
{
    return str_pad(str_pad("  " . $cmd, 20) . " " . str_pad($value, 10), 15) . "  " . ($comments_wanted ? $comment : "");
}

/**
 * ****************************************************************************
 */
function pad_A($s)
{
    return str_pad($s, 25);
}

/**
 * ****************************************************************************
 */
function pad_B($s)
{
    return str_pad($s, 20);
}

/**
 * ****************************************************************************
 */
function make_maked_item($in, $marker)
{
    return '<' . $marker . '>' . $in . '</' . $marker . '>';
}

/**
 * ****************************************************************************
 */
function extract_marked_item(&$line, $marker, $delete_from_line)
{
    $m_front = '<' . $marker . '>';
    $m_end = '</' . $marker . '>';
    $f = strpos($line, $m_front);
    $e = strpos($line, $m_end);

    if ($f == - 1)
        return '';

    $f += strlen($m_front);

    $s = '';

    if ($f < $e) {
        $s = substr($line, $f, $e - $f);

        if ($delete_from_line) {
            str_replace($s, "", $line);
        }
    }

    return $s;
}

/**
 * ****************************************************************************
 */
function path_to_nix($p)
{
    return str_replace("\\", "/", $p);
}

/**
 * ****************************************************************************
 */
function get_dealer_app()
{
    $os = substr(PHP_OS, 0, 3);

    if ($os === 'WIN') {
        $home_folder = $_SERVER['HOMEDRIVE'] . $_SERVER['HOMEPATH'];
        $app = 'dealer.exe';
    }
    else {
        $home_folder = $_SERVER['HOME'];
        $app = 'dealer';
    }

    return '"' . path_to_nix($home_folder) . '/aaBridge/cmds_and_scripts/' . $app . '"';
}





// /**
//  * ****************************************************************************
//  */
// function rrmdir ($dir)
// {
//    if (is_dir($dir)) {
//       $objects = scandir($dir);
//       foreach ($objects as $object) {
//          if ($object != "." && $object != "..") {
//             if (filetype($dir . "/" . $object) == "dir")
//                rrmdir($dir . "/" . $object);
//             else
//                unlink($dir . "/" . $object);
//          }
//       }
//       reset($objects);
//       rmdir($dir);
//    }
// }
