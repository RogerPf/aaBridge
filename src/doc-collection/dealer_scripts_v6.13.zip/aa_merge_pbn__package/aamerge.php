<?php
error_reporting(E_ALL);

date_default_timezone_set('Europe/London');

main();

exit(0);

// ****************************************************************************
function main()
{
    $app_text = "     Version 1.50    last updated  2016-11-16";
    
    global $argv;
    
    // print_r ($argv);
    
    $current_app_name = substr(pathinfo($argv[0], PATHINFO_BASENAME), 0, - 4);
    
    $firstPbnFileName = "";
    $fn_out_ip = "";
    $fn_out = "";
    $fn_out_short = "";
    
    $pbnFiles = array();
    $qMaster = new QMaster();
    
    $random_selection = false;
    $newBoardNumber = 1;
    
    $out = "";
    
    $first = true;
    
    $ratioToTake = 1;
    
    $max_limit = 9999999;
    $early_limit = 9999999;
    
    $namePrefix = "yyMERGED__inc__";
    
    $check_second = 0;
    
    for ($i = 0; $i < count($argv); $i ++) {
        if (strtolower($argv[$i]) === "-r") {
            print "Random select:  Yes" . PHP_EOL;
            $random_selection = true;
            $argv[$i] = "";
        }
    }
    
    for ($i = 0; $i < count($argv); $i ++) {
        if (strtolower($argv[$i]) === "-m") {
            $max_limit = $argv[$i + 1];
            print "Max Limit set:  $max_limit" . PHP_EOL;
            $argv[$i] = "";
            $argv[$i + 1] = "";
        }
    }
    
    for ($i = 0; $i < count($argv); $i ++) {
        if (strtolower($argv[$i]) === "-o") {
            $fn_out_ip = $argv[$i + 1];
            $fn_out_ip = addPbnIfNeeded($fn_out_ip);
            print "Output name:    $fn_out_ip" . PHP_EOL;
            $argv[$i] = "";
            $argv[$i + 1] = "";
        }
    }
    
    for ($i = 0; $i < count($argv); $i ++) {
        if (strtolower($argv[$i]) === "-f") {
            $filelistName = $argv[$i + 1];
            print "Pbn file list:  $filelistName" . PHP_EOL;
            $argv[$i] = "";
            $argv[$i + 1] = "";
        }
    }
    
    // print_r ($argv);
    
    if (isset($filelistName)) {
        
        print PHP_EOL;
        
        $filelist = file($filelistName, FILE_IGNORE_NEW_LINES);
        
        if ($filelist == false || $filelist == null) {
            echo "$current_app_name  -f $filelistName       -      file  $filelistName    not found  OR not vaild, empty ?" . PHP_EOL;
            exit(0);
        }
        
        $base = dirname($filelistName);
        chdir($base);
        
        foreach ($filelist as $lineKey => $line) {
            
            $line = trim($line);
            
            if ($line === "") {
                continue;
            }
            
            if (substr($line, 0, 1) === "#") {
                continue;
            }         

            if (strtolower(substr($line, 0, 2) === "-r")) {
                print "Random select:  Yes" . PHP_EOL;
                $random_selection = true;
                continue;
            }

            if (strtolower(substr($line, 0, 2) === "-m")) {
                $max_limit = trim(substr($line, 2));
                print "Max Limit set:  $max_limit" . PHP_EOL;
                continue;
            }
            
            if (strtolower(substr($line, 0, 2) === "-o")) {
                $fn_out_ip = addPbnIfNeeded(trim(substr($line, 2)));
                print "Output name:    $fn_out_ip" . PHP_EOL;
                continue;
            }
            
            if (strlen($line) < 5)
                continue;
            
            $c2 = substr($line, 1, 1);
            if ($c2 === " " || $c2 === "\t") { // i.e. test the second character
                $ratioToTake = substr($line, 0, 1);
                if ($ratioToTake + 0 == 0) {
                    $ratioToTake = 0;
                }
                $line = trim(substr($line, 1));
            }
            
            $fname = $line;
            
            $pbnFiles[] = $pbn = new PbnFile($qMaster, $fname, $ratioToTake);
            
            if (($firstPbnFileName === "") && ($ratioToTake > 0) && ($pbn->getCount() > 0)) {
                $firstPbnFileName = $fname;
            }
            
            $ratioToTake = 1; // preset for the next cycyle
        }
    } else {
        
        foreach ($argv as $argKey => $arg) {
            
            /*
             * This is a list of pbns as arguments that we need to merge
             *
             */
            
            if ($argKey == 0)
                continue;
            
            if ($arg === "") {
                continue;
            }
            
            if (strlen($arg) == 1) {
                $ratioToTake = $arg;
                if ($ratioToTake + 0 == 0) {
                    $ratioToTake = 0;
                }
                continue;
            }
            
            $fname = $arg;
            
            if (endsWith($fname, ".pbn") == false) {
                print "  File   $fname   does not end with    .pbn " . PHP_EOL;
                exit(2);
            }
            
            if (in_array($fname, $pbnFilesNames)) {
                // this fixes argv duplication bug in DOS box windows 7 php ver
                continue;
            }
            
            $pbnFiles[] = new PbnFile($qMaster, $fname, $ratioToTake);
            
            $ratioToTake = 1; // preset for next cycle
            
            if ($firstPbnFileName === "") {
                $firstPbnFileName = $fname;
            }
        }
    }
    
    if ($firstPbnFileName == "") {
        print PHP_EOL . $current_app_name . $app_text . PHP_EOL . PHP_EOL;
        print "Usage:   " . PHP_EOL . PHP_EOL;
        print " $current_app_name [-r] [-m numb] [-o fname] [digit] <file>  [digit] <file> ... repeating" . PHP_EOL;
        print "OR" . PHP_EOL;
        print " $current_app_name [-r] [-m numb] [-o fname] -f <fileList>" . PHP_EOL . PHP_EOL;
        print "";
        print "  [-r]          = select the deals randomly. [OPTIONAL]" . PHP_EOL;
        print "  [-m numb]     = numb is Maximum number of deals to merge in total. [OPTIONAL]" . PHP_EOL;
        print "  [-o fname]    = fname is the output file name. [OPTIONAL]" . PHP_EOL;
        print "  [digit]       = the ratio of deals to be read from that pbn file. [OPTIONAL]" . PHP_EOL;
        print "  <file>        = name of a  .pbn  file to merge." . PHP_EOL;
        print "  -f <fileList> = the name of a text file containg a list of  pbn  files." . PHP_EOL;
        print "                        That file can start with  -r  and/or  -m numb" . PHP_EOL . PHP_EOL;
        
        print "       DO NOT use SPACES in any filenames,  use underscore '_' instead." . PHP_EOL . PHP_EOL;
        
        print "  Examples: " . PHP_EOL . PHP_EOL;
        
        print "     $current_app_name  fileA.pbn  fileB.pbn" . PHP_EOL;
        print "     $current_app_name  fileCC.pbn  2 fileEE.pbn" . PHP_EOL;
        print "     $current_app_name  -r   -m 40   fileA.pbn  3 fileB.pbn  2 fileC.pbn" . PHP_EOL;
        print "     $current_app_name  -o outputfileName.pbn  -f  pbnFileList.txt" . PHP_EOL;
        print "     $current_app_name  -f pbnFileList.txt" . PHP_EOL . PHP_EOL . PHP_EOL;
        
        print "  The output .pbn  file will have a name starting with    " . $namePrefix . PHP_EOL . PHP_EOL;
        
        print "   (remember when typing filenames you can use  TAB  for file name completion)" . PHP_EOL . PHP_EOL;
        
        exit(0);
    }
    
    $fn_out = $fn_out_ip;
    
    if ($fn_out === "") {
        $fn_out = $firstPbnFileName;
    }
    
    $fn_out = pathinfo($fn_out, PATHINFO_DIRNAME) . "/" . $namePrefix . pathinfo($fn_out, PATHINFO_FILENAME) . ".pbn";
    $fn_out_short = pathinfo($fn_out, PATHINFO_BASENAME);
    
    // Merge and output time
    
    print PHP_EOL;
    print "Output file:    $fn_out_short" . PHP_EOL;
    
    $fout = fopen($fn_out, 'w'); // create the outputfile // which will overwrite any existing file.
    
    $qMaster->merge($random_selection, $max_limit);
    
    if (count($qMaster->countQueues()) == 0) {
        print "  No pbn files supplied   or   ALL valid pbn files have been excluded" . PHP_EOL . PHP_EOL;
        exit(2);
    }
    
    $qMaster->writeMergedToFile($fout, $fn_out_short, $fn_out_ip);
    
    print PHP_EOL;
    
    // Show the user how many of what were taken
    
    print "Avail:  Taken:  Ratio:" . PHP_EOL;
    
    foreach ($pbnFiles as $pbnFile) {
        
        $avail = padded3($pbnFile->getCount(), false);
        $taken = padded3($pbnFile->getNumberTaken(), $pbnFile->ratioToTake + 0 == 0);
        $to_take = padded3($pbnFile->ratioToTake, true);
        
        print "  $avail     $taken     $to_take  " . pathinfo($pbnFile->fname, PATHINFO_BASENAME) . PHP_EOL;
    }
    
    print PHP_EOL;
}

/**
 * ****************************************************************************
 *
 * @author roger
 *        
 */
class QMaster
{

    public $dealQueues = array();

    public $merged = array();

    public function countQueues()
    {
        return count($this->dealQueues);
    }

    public function addQueue($dealQueue)
    {
        $this->dealQueues[] = $dealQueue;
    }

    public function merge($random_selection, $max_limit)
    {
        $total = 0;
        
        while (true) {
            
            $found = false;
            
            foreach ($this->dealQueues as $dealQueue) {
                if ($dealQueue->takeNext()) {
                    $found = true;
                    $total ++;
                    if ($total == 1) {
                        // always write the first one out at once - for the embedded name
                        $this->merged[] = $dealQueue->getAndClearTaken();
                    }
                    if ($total >= $max_limit)
                        break;
                }
            }
            
            if ($found == false)
                break;
            
            if ($random_selection) {
                shuffle($this->dealQueues);
            }
            
            foreach ($this->dealQueues as $dealQueue) {
                if ($dealQueue->isTakenValid()) {
                    $this->merged[] = $dealQueue->getAndClearTaken();
                }
            }
            
            if ($total >= $max_limit)
                break;
        }
    }

    public function writeMergedToFile($fo_out, $fn_out_short, $fn_out_ip)
    {
        foreach ($this->merged as $pbn) {
            $pbn->writeDealTofile($fo_out, $fn_out_short, $fn_out_ip);
        }
        
        flush($fo_out);
    }
}

/**
 * ****************************************************************************
 *
 * @author roger
 *        
 */
class Pbn
{

    public $pbnLines;

    function Pbn($pbnLines)
    {
        $this->pbnLines = $pbnLines;
    }

    function writeDealToFile($fo, $fn_out_short, $overwrite_name)
    {
        static $newBoardNumber = 1;
        
        foreach ($this->pbnLines as $line) {
            
            if (($newBoardNumber == 1) && substr($line, 0, 6) == '[Event') {
                
                static $start_match = 'with file ';
                $sm_len = strlen($start_match);
                $matchFrom = strpos($line, $start_match) + $sm_len;
                $final_dottxt = strrpos($line, '.txt') + 4;
                
                $script_name = "No_dealer_script_name_found_in_pbn_file.txt";
                $seed = "0000000000";
                
                if (($matchFrom > $sm_len) && ($final_dottxt > $matchFrom)) {
                    $script_name = substr($line, $matchFrom, $final_dottxt - $matchFrom);
                    $script_name = trim($script_name);
                    
                    static $start_match2 = 'seed';
                    $sm2_len = strlen($start_match2);
                    $matchFrom2 = strpos($line, $start_match2) + $sm2_len;
                    
                    $end2 = strrpos($line, '"');
                    if (($matchFrom2 > $sm2_len) && ($end2 > 0)) {
                        $seed = substr($line, $matchFrom2, $end2 - $matchFrom2);
                        $seed = trim($seed);
                    }
                }
                
                if ($overwrite_name !== "") {
                    $script_name = substr($overwrite_name, 0, - 4) . ".txt"; // change the .bpn to a .txt
                }
                
                $line = '[Event "Hand simulated by dealer with file __MERGED__inc__' . $script_name . ', seed ' . $seed . '"]';
            }
            
            if (substr($line, 0, 6) === '[Board') {
                $line = '[Board "' . $newBoardNumber ++ . '"]';
            }
            
            fwrite($fo, $line . chr(10)); // unix/mac EOL
        }
        
        fwrite($fo, "" . chr(10)); // unix/mac blank line on the end
    }
}

/**
 * ****************************************************************************
 *
 * @author roger
 *        
 */
class DealQueue
{

    public $pbnFile;

    public $taken;

    function DealQueue($pbnFile)
    {
        $this->pbnFile = $pbnFile;
        $this->taken = null;
    }

    function takeNext()
    {
        $this->taken = $this->pbnFile->takeNext();
        return $this->taken != null;
    }

    function isTakenValid()
    {
        return $this->taken != null;
    }

    function getAndClearTaken()
    {
        $pbn = $this->taken;
        $this->taken = null;
        return $pbn;
    }
}

/**
 * ****************************************************************************
 *
 * @author roger
 *        
 */
class PbnFile
{

    public $fname;

    public $ratioToTake;

    public $nextToTake = 0;

    public $pbns = array();

    function takeNext()
    {
        if ($this->nextToTake >= count($this->pbns))
            return null;
        
        return $this->pbns[$this->nextToTake ++];
    }

    function getCount()
    {
        return count($this->pbns);
    }

    function getNumberTaken()
    {
        return $this->nextToTake;
    }

    function PbnFile(&$qMaster, $fname, $ratioToTake)
    {
        if (endsWith($fname, ".pbn") == false) {
            print "  File   $fname   does not end with    .pbn " . PHP_EOL;
            exit(2);
        }
        
        $this->fname = $fname;
        $this->ratioToTake = $ratioToTake;
        
        $CR = chr(13);
        $LF = chr(10);
        
        // $to_take = $ratioToTake;
        // if ($to_take == 0) $to_take = "-";
        // if ($to_take == 1) $to_take = " ";
        
        // print " input_file $to_take " . pathinfo( $fname, PATHINFO_BASENAME) . PHP_EOL;
        
        $file = fopen($this->fname, "rb");
        
        if ($file === false) {
            print "  Cannot open file   $this->fname" . PHP_EOL;
            exit(2);
        }
        
        $fs_in = stream_get_meta_data($file)["uri"];
        
        $data = file_get_contents($fs_in); // read in source lin file (any UTF8 text file)
        
        $data = str_ireplace($LF . $CR, $LF, $data, $v0);
        $data = str_ireplace($CR . $LF, $LF, $data, $v1);
        $data = str_ireplace($CR, $LF, $data, $v2);
        
        $raw_hands = explode($LF . $LF, $data);
        
        while (substr(end($raw_hands), 0, 1) != "[") {
            array_pop($raw_hands);
        }
        
        foreach ($raw_hands as $raw_h) {
            $this->pbns[] = new Pbn(explode($LF, $raw_h));
        }
        
        for ($i = 0; $i < $ratioToTake; $i ++) {
            $qMaster->addQueue(new dealQueue($this));
        }
    }
}

/**
 * ****************************************************************************
 */
function addPbnIfNeeded($name)
{
    if (endsWith(strtoLower($name), ".pbn"))
        return $name;
    else
        return $name . ".pbn";
}

/**
 * ****************************************************************************
 */
function endsWith($str, $end)
{
    return substr(strToLower($str), - strlen($end)) === $end;
}

/**
 * ****************************************************************************
 */
function padded3($s, $use_hyphen)
{
    if ($use_hyphen && $s + 0 == 0)
        $s = "-";
    if (strlen($s) == 0)
        return "   " . $s;
    if (strlen($s) == 1)
        return "  " . $s;
    if (strlen($s) == 2)
        return " " . $s;
    return $s;
}





